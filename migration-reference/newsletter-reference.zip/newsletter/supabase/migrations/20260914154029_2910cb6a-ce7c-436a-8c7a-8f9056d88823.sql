ALTER TABLE public.briefs
  ADD COLUMN IF NOT EXISTS titulo_editorial text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS tese_editorial text NOT NULL DEFAULT '';