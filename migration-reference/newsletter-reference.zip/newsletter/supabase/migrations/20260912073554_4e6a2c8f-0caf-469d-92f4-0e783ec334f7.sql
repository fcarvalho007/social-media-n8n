ALTER TABLE public.ia_uso DROP CONSTRAINT IF EXISTS ia_uso_origem_check;
ALTER TABLE public.ia_uso ADD CONSTRAINT ia_uso_origem_check CHECK (origem = ANY (ARRAY[
  'colagem_manual','curadoria_rss','sugerir_assunto','encurtar_descricao','pesquisar_fonte',
  'embedding_deteccao_repeticao','confirmar_repeticao','curadoria_fila','extraccao_noticia',
  'descricao_reescrita','minha_leitura','email','email_newsletter','manual_ia',
  'sugestao_organizacao','preparar_consulta_fonte','curadoria_ferramentas_relevancia',
  'curadoria_ferramentas_polimento'
]));