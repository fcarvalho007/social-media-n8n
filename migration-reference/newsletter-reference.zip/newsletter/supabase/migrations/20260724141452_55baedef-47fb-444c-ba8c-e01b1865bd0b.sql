
CREATE OR REPLACE FUNCTION public.reordenar_seccoes(_edicao_id uuid, _ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _estado text;
  _papel text;
BEGIN
  SELECT estado INTO _estado FROM edicoes WHERE id = _edicao_id;
  IF _estado IS DISTINCT FROM 'rascunho' THEN
    RAISE EXCEPTION 'Edição não está em rascunho';
  END IF;
  _papel := me_papel();
  IF _papel NOT IN ('admin','curador') THEN
    RAISE EXCEPTION 'Sem permissão';
  END IF;
  -- Passo intermédio para evitar colisões de ordem
  UPDATE secoes_edicao SET ordem = -1000 - ordem WHERE edicao_id = _edicao_id;
  UPDATE secoes_edicao s
     SET ordem = t.pos
    FROM (SELECT unnest(_ids) AS id, generate_subscripts(_ids, 1) - 1 AS pos) t
   WHERE s.id = t.id AND s.edicao_id = _edicao_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.reordenar_noticias(_edicao_id uuid, _ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _estado text;
  _papel text;
BEGIN
  SELECT estado INTO _estado FROM edicoes WHERE id = _edicao_id;
  IF _estado IS DISTINCT FROM 'rascunho' THEN
    RAISE EXCEPTION 'Edição não está em rascunho';
  END IF;
  _papel := me_papel();
  IF _papel NOT IN ('admin','curador') THEN
    RAISE EXCEPTION 'Sem permissão';
  END IF;
  UPDATE noticias SET ordem = -1000 - ordem WHERE edicao_id = _edicao_id;
  UPDATE noticias n
     SET ordem = t.pos
    FROM (SELECT unnest(_ids) AS id, generate_subscripts(_ids, 1) - 1 AS pos) t
   WHERE n.id = t.id AND n.edicao_id = _edicao_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.reordenar_seccoes(uuid, uuid[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.reordenar_noticias(uuid, uuid[]) TO authenticated;
