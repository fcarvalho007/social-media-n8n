
-- (1) REVOKE EXECUTE FROM PUBLIC nas RPCs de reordenação/estrutura
REVOKE EXECUTE ON FUNCTION public.mover_seccao(uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.reordenar_seccoes(uuid, uuid[]) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.reordenar_noticias(uuid, uuid[]) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.criar_seccoes_padrao(uuid) FROM PUBLIC;

-- Re-afirma os GRANTs certos
GRANT EXECUTE ON FUNCTION public.mover_seccao(uuid, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.reordenar_seccoes(uuid, uuid[]) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.reordenar_noticias(uuid, uuid[]) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.criar_seccoes_padrao(uuid) TO authenticated, service_role;

-- (2) Backfill conteudo_html a partir de conteudo em texto plano (edições antigas)
UPDATE public.cronicas
SET conteudo_html = '<p>' || regexp_replace(trim(conteudo), E'\n+', '</p><p>', 'g') || '</p>'
WHERE (conteudo_html IS NULL OR btrim(conteudo_html) = '')
  AND conteudo IS NOT NULL
  AND btrim(conteudo) <> '';
