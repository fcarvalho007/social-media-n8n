ALTER TABLE public.revista_edicao
  ADD COLUMN IF NOT EXISTS cronica_lede_posicao integer NOT NULL DEFAULT 0;