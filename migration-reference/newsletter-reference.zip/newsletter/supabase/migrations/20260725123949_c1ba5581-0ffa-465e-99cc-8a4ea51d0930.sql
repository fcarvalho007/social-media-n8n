CREATE OR REPLACE FUNCTION public.set_actualizado_em()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.actualizado_em = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_configuracoes_updated ON public.configuracoes;

CREATE TRIGGER trg_configuracoes_updated
  BEFORE UPDATE ON public.configuracoes
  FOR EACH ROW EXECUTE FUNCTION public.set_actualizado_em();