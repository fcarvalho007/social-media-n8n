CREATE TABLE public.ferramentas_sugeridas (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome text NOT NULL,
  url text NOT NULL,
  descricao text,
  categoria text,
  fonte_email_id uuid REFERENCES public.emails_recebidos(id) ON DELETE SET NULL,
  remetente text,
  assunto_origem text,
  estado text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente','aprovada','rejeitada','arquivada')),
  aprovada_em timestamptz,
  criado_em timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ferramentas_sugeridas_url_unico ON public.ferramentas_sugeridas (lower(url));
CREATE INDEX ferramentas_sugeridas_estado_idx ON public.ferramentas_sugeridas (estado);
CREATE INDEX ferramentas_sugeridas_email_idx ON public.ferramentas_sugeridas (fonte_email_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ferramentas_sugeridas TO authenticated;
GRANT ALL ON public.ferramentas_sugeridas TO service_role;

ALTER TABLE public.ferramentas_sugeridas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ferramentas_read_auth" ON public.ferramentas_sugeridas
  FOR SELECT TO authenticated
  USING (public.me_papel() IN ('admin','curador'));

CREATE POLICY "ferramentas_insert_auth" ON public.ferramentas_sugeridas
  FOR INSERT TO authenticated
  WITH CHECK (public.me_papel() IN ('admin','curador'));

CREATE POLICY "ferramentas_update_auth" ON public.ferramentas_sugeridas
  FOR UPDATE TO authenticated
  USING (public.me_papel() IN ('admin','curador'))
  WITH CHECK (public.me_papel() IN ('admin','curador'));

CREATE POLICY "ferramentas_delete_admin" ON public.ferramentas_sugeridas
  FOR DELETE TO authenticated
  USING (public.me_papel() = 'admin');

CREATE TRIGGER ferramentas_sugeridas_set_updated_at
  BEFORE UPDATE ON public.ferramentas_sugeridas
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();