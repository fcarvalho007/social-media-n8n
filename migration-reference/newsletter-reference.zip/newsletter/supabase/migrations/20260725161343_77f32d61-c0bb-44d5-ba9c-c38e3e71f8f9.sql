ALTER TABLE public.edicoes
  ADD COLUMN IF NOT EXISTS links_verificados jsonb,
  ADD COLUMN IF NOT EXISTS links_verificados_em timestamptz;