ALTER TABLE public.curadoria_config
  ADD COLUMN IF NOT EXISTS max_por_dia_email integer NOT NULL DEFAULT 15;