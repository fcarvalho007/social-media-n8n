
ALTER TABLE public.noticias DROP CONSTRAINT IF EXISTS noticias_origem_check;
ALTER TABLE public.noticias ADD CONSTRAINT noticias_origem_check
  CHECK (origem = ANY (ARRAY['form_unica','form_bloco','whatsapp','curadoria_ia','manual','manual_ia','email_newsletter']));

ALTER TABLE public.noticias
  ADD COLUMN IF NOT EXISTS email_remetente text,
  ADD COLUMN IF NOT EXISTS email_assunto text;

CREATE INDEX IF NOT EXISTS idx_noticias_origem ON public.noticias(origem);
