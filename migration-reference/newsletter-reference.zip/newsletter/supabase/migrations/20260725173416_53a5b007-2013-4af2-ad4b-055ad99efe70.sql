
-- Grants em falta
GRANT SELECT, INSERT, UPDATE, DELETE ON public.emails_recebidos TO authenticated;
GRANT ALL ON public.emails_recebidos TO service_role;

-- Policies INSERT/UPDATE (SELECT/DELETE já existem)
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='emails_recebidos' AND policyname='Autenticados podem inserir emails recebidos') THEN
    CREATE POLICY "Autenticados podem inserir emails recebidos"
      ON public.emails_recebidos FOR INSERT TO authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='emails_recebidos' AND policyname='Autenticados podem actualizar emails recebidos') THEN
    CREATE POLICY "Autenticados podem actualizar emails recebidos"
      ON public.emails_recebidos FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

-- Realtime
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='emails_recebidos'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.emails_recebidos';
  END IF;
END $$;
ALTER TABLE public.emails_recebidos REPLICA IDENTITY FULL;

-- Cron diário: retenção 14 dias
CREATE EXTENSION IF NOT EXISTS pg_cron;
DO $$ BEGIN
  PERFORM cron.unschedule('purgar_emails_recebidos_14d');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
SELECT cron.schedule(
  'purgar_emails_recebidos_14d',
  '0 4 * * *',
  $$DELETE FROM public.emails_recebidos WHERE recebido_em < now() - interval '14 days'$$
);
