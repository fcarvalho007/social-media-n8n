// Server functions para o diretório de Ferramentas Sugeridas
// extraídas automaticamente das newsletters recebidas.

import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { normalizarNome } from "../../supabase/functions/_shared/scrapers-ferramentas";

export type FerramentaSugerida = {
  id: string;
  nome: string;
  url: string;
  descricao: string | null;
  descricao_original?: string | null;
  emoji?: string | null;
  cor?: string | null;
  categoria: string | null;
  remetente: string | null;
  assunto_origem: string | null;
  fonte_email_id: string | null;
  fonte_directorio_id?: string | null;
  estado: "pendente" | "aprovada" | "rejeitada" | "arquivada";
  aprovada_em: string | null;
  criado_em: string;
  edicao_aprovada_id?: string | null;
  edicao_aprovada_numero?: number | null;
};

export type FiltroEstadoFerramenta = "pendente" | "aprovada" | "rejeitada" | "arquivada" | "todas";

export const listarFerramentas = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((data: { estado?: FiltroEstadoFerramenta } | undefined) => data ?? {})
  .handler(async ({ data, context }): Promise<{
    ferramentas: FerramentaSugerida[];
    contagens: { pendente: number; aprovada: number; rejeitada: number; arquivada: number; total: number };
  }> => {
    const contar = async (estado: FiltroEstadoFerramenta) => {
      let q = context.supabase.from("ferramentas_sugeridas").select("id", { count: "exact", head: true });
      if (estado !== "todas") q = q.eq("estado", estado);
      const { count } = await q;
      return count ?? 0;
    };
    const [total, pendente, aprovada, rejeitada, arquivada] = await Promise.all([
      contar("todas"), contar("pendente"), contar("aprovada"), contar("rejeitada"), contar("arquivada"),
    ]);

    let q = context.supabase
      .from("ferramentas_sugeridas")
      .select("id, nome, url, descricao, descricao_original, emoji, cor, categoria, remetente, assunto_origem, fonte_email_id, fonte_directorio_id, estado, aprovada_em, criado_em, edicao_aprovada_id");
    if (data.estado && data.estado !== "todas") q = q.eq("estado", data.estado);
    const { data: rows, error } = await q.order("criado_em", { ascending: false }).limit(200);
    if (error) throw new Error(error.message);

    // Enriquecer com número da edição aprovada (uma query só, para tudo).
    const rowsArr = (rows ?? []) as unknown as FerramentaSugerida[];
    const edIds = Array.from(new Set(rowsArr
      .map((r) => r.edicao_aprovada_id)
      .filter((v): v is string => !!v)));
    const numerosPorId = new Map<string, number>();
    if (edIds.length > 0) {
      const { data: eds } = await context.supabase
        .from("edicoes").select("id, numero").in("id", edIds);
      for (const e of eds ?? []) numerosPorId.set(e.id, e.numero);
    }
    for (const r of rowsArr) {
      r.edicao_aprovada_numero = r.edicao_aprovada_id ? numerosPorId.get(r.edicao_aprovada_id) ?? null : null;
    }

    return {
      ferramentas: rowsArr,
      contagens: { total, pendente, aprovada, rejeitada, arquivada },
    };
  });

export const actualizarEstadoFerramenta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: { id: string; estado: "pendente" | "aprovada" | "rejeitada" | "arquivada" }) => {
    if (!data?.id) throw new Error("id inválido");
    if (!["pendente", "aprovada", "rejeitada", "arquivada"].includes(data.estado)) {
      throw new Error("estado inválido");
    }
    return data;
  })
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    const patch: Record<string, unknown> = { estado: data.estado };
    if (data.estado === "aprovada") patch.aprovada_em = new Date().toISOString();
    const { error } = await context.supabase
      .from("ferramentas_sugeridas")
      .update(patch as never)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const apagarFerramenta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: { id: string }) => {
    if (!data?.id) throw new Error("id inválido");
    return data;
  })
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    const { error } = await context.supabase.from("ferramentas_sugeridas").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listarFerramentasDoEmail = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((data: { emailId: string }) => {
    if (!data?.emailId) throw new Error("emailId inválido");
    return data;
  })
  .handler(async ({ data, context }): Promise<FerramentaSugerida[]> => {
    const { data: rows, error } = await context.supabase
      .from("ferramentas_sugeridas")
      .select("id, nome, url, descricao, descricao_original, emoji, cor, categoria, remetente, assunto_origem, fonte_email_id, fonte_directorio_id, estado, aprovada_em, criado_em")
      .eq("fonte_email_id", data.emailId)
      .order("criado_em", { ascending: true });
    if (error) throw new Error(error.message);
    return (rows ?? []) as unknown as FerramentaSugerida[];
  });

/** Aprova uma sugestão E insere-a no primeiro slot livre (1 ou 2) da
 *  edição em rascunho mais recente. Devolve o id da nova ferramenta_semana
 *  e o número da edição alvo. */
export const aprovarFerramentaParaRascunho = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: { id: string; edicao_id?: string }) => {
    if (!data?.id) throw new Error("id inválido");
    return data;
  })
  .handler(async ({ data, context }): Promise<{
    ok: true; edicao_numero: number; posicao: 1 | 2; template_version: string;
  } | { ok: false; motivo: string }> => {
    // 1) Buscar a ferramenta sugerida
    const { data: f, error: eF } = await context.supabase
      .from("ferramentas_sugeridas")
      .select("id, nome, url, descricao, emoji, cor")
      .eq("id", data.id)
      .maybeSingle();
    if (eF) throw new Error(eF.message);
    if (!f) return { ok: false, motivo: "Ferramenta não encontrada" };

    // 2) Edição alvo: a escolhida, ou a edição em rascunho mais recente
    const baseQ = context.supabase
      .from("edicoes")
      .select("id, numero, template_version")
      .eq("estado", "rascunho");
    const { data: ed, error: eEd } = data.edicao_id
      ? await baseQ.eq("id", data.edicao_id).maybeSingle()
      : await baseQ.order("numero", { ascending: false }).limit(1).maybeSingle();
    if (eEd) throw new Error(eEd.message);
    if (!ed) {
      return {
        ok: false,
        motivo: data.edicao_id
          ? "Essa edição já não está em rascunho."
          : "Não existe edição em rascunho. Cria uma primeiro.",
      };
    }

    // 3) Slots ocupados
    const { data: ocupados } = await context.supabase
      .from("ferramentas_semana")
      .select("posicao")
      .eq("edicao_id", ed.id);
    const posicoes = new Set((ocupados ?? []).map((r) => r.posicao));
    const posicao: 1 | 2 | null = !posicoes.has(1) ? 1 : !posicoes.has(2) ? 2 : null;
    if (posicao === null) return { ok: false, motivo: "Ambos os slots da edição estão ocupados." };

    // 4) Insert em ferramentas_semana + marcar aprovada
    const cor = (f as { cor?: string | null }).cor ?? "indigo";
    const emoji = (f as { emoji?: string | null }).emoji ?? "🛠️";
    const { error: eIns } = await context.supabase.from("ferramentas_semana").insert({
      edicao_id: ed.id,
      posicao,
      nome: f.nome,
      descricao: f.descricao,
      url: f.url,
      emoji,
      cor,
    } as never);
    if (eIns) throw new Error(eIns.message);

    await context.supabase
      .from("ferramentas_sugeridas")
      .update({
        estado: "aprovada",
        aprovada_em: new Date().toISOString(),
        edicao_aprovada_id: ed.id,
      } as never)
      .eq("id", data.id);

    return {
      ok: true,
      edicao_numero: ed.numero,
      posicao,
      template_version: (ed as { template_version?: string | null }).template_version ?? "classico",
    };
  });

/** Edições em rascunho que podem receber uma ferramenta, com o formato
 *  (Clássico/Revista) e os lugares (1 e 2) ainda livres. */
export const listarEdicoesDestinoFerramenta = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((data: Record<string, never> | undefined) => data ?? {})
  .handler(async ({ context }): Promise<Array<{
    id: string; numero: number; template_version: string; livres: number;
  }>> => {
    const { data: eds, error } = await context.supabase
      .from("edicoes")
      .select("id, numero, template_version")
      .eq("estado", "rascunho")
      .order("numero", { ascending: false })
      .limit(10);
    if (error) throw new Error(error.message);
    const lista = (eds ?? []) as Array<{ id: string; numero: number; template_version: string | null }>;
    if (lista.length === 0) return [];

    const { data: slots } = await context.supabase
      .from("ferramentas_semana")
      .select("edicao_id, posicao")
      .in("edicao_id", lista.map((e) => e.id));
    const ocupadosPorEd = new Map<string, Set<number>>();
    for (const s of (slots ?? []) as Array<{ edicao_id: string; posicao: number }>) {
      const set = ocupadosPorEd.get(s.edicao_id) ?? new Set<number>();
      set.add(s.posicao);
      ocupadosPorEd.set(s.edicao_id, set);
    }

    return lista.map((e) => {
      const ocup = ocupadosPorEd.get(e.id) ?? new Set<number>();
      return {
        id: e.id,
        numero: e.numero,
        template_version: e.template_version ?? "classico",
        livres: [1, 2].filter((p) => !ocup.has(p)).length,
      };
    });
  });

/** Rejeita a ferramenta E bane-a por domínio E por nome normalizado,
 *  para que a curadoria automática não a volte a sugerir a partir de
 *  outra fonte com URL diferente. */
export const rejeitarFerramentaComBan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: { id: string }) => {
    if (!data?.id) throw new Error("id inválido");
    return data;
  })
  .handler(async ({ data, context }): Promise<{ ok: true; dominio: string | null; nome_norm: string | null }> => {
    const { data: f } = await context.supabase
      .from("ferramentas_sugeridas")
      .select("nome, url")
      .eq("id", data.id)
      .maybeSingle();

    let dominio: string | null = null;
    if (f?.url) {
      try { dominio = new URL(f.url).hostname.replace(/^www\./, "").toLowerCase(); } catch { /* noop */ }
    }
    const nomeNorm = f?.nome ? normalizarNome(f.nome) : null;

    // Duas linhas independentes na lista de excluídas (uma por dominio, outra
    // por nome_norm) — o unique index em `dominio` protege contra duplicados,
    // e uma segunda linha com `dominio=null` + `nome_norm` cobre o mesmo nome
    // vindo de outra origem.
    if (dominio) {
      await context.supabase
        .from("ferramentas_excluidas" as never)
        .upsert({ dominio, nome_norm: nomeNorm, motivo: "rejeitada_no_editor" } as never,
          { onConflict: "dominio" } as never);
    }
    if (nomeNorm && !dominio) {
      // sem domínio válido: garante pelo menos a linha por nome
      await context.supabase
        .from("ferramentas_excluidas" as never)
        .insert({ dominio: null, nome_norm: nomeNorm, motivo: "rejeitada_no_editor" } as never);
    }

    await context.supabase
      .from("ferramentas_sugeridas")
      .update({ estado: "rejeitada" } as never)
      .eq("id", data.id);
    return { ok: true, dominio, nome_norm: nomeNorm };
  });

/** Contagem barata de sugestões arquivadas — usado pela sugestão suave
 *  na secção Ferramentas da Semana do editor. */
export const contarFerramentasArquivadas = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ total: number }> => {
    const { count } = await context.supabase
      .from("ferramentas_sugeridas")
      .select("id", { count: "exact", head: true })
      .eq("estado", "arquivada");
    return { total: count ?? 0 };
  });
