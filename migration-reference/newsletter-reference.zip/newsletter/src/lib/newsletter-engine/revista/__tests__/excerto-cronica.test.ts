import { describe, it, expect } from "vitest";
import { excertoDaCronica } from "../compose.server";

describe("excertoDaCronica", () => {
  it("converte HTML em parágrafos", () => {
    expect(excertoDaCronica("<p>Olá.</p><p>Mundo &amp; mais.</p>")).toBe("Olá.\n\nMundo & mais.");
  });
  it("corta no fim de uma frase", () => {
    const r = excertoDaCronica("<p>" + "Frase curta aqui. ".repeat(60) + "</p>", 100);
    expect(r.length).toBeLessThanOrEqual(100);
    expect(r.endsWith(".")).toBe(true);
  });
});
