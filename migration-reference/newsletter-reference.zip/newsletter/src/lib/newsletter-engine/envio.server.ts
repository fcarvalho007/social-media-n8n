// Implementação servidor do fluxo de preview / sincronização / envio.
// Porta directa das antigas Edge Functions (preview-edicao,
// sincronizar-rascunho-egoi, disparar-egoi, publicar-wordpress) para o
// runtime da aplicação, mantendo exactamente as mesmas regras.

import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { renderEdicaoEmail } from "./render.server";
import { gerarHtmlEdicaoWeb } from "./gerar-html-web.server";
import {
  bloquearSnapshotRevista, composeRevistaEdition, descartarSnapshotPreparado,
  lerSnapshotRevista, prepararSnapshotRevista,
} from "./revista/compose.server";
import { montarHtmlRevista } from "./revista/render-email.server";
import { montarTextoRevista } from "./revista/texto.server";
import { lerConfig, resolverListas, sincronizar, sincronizarUmaLista } from "./sincronizar-egoi.server";
import { disparaCampanha, estadoCampanha } from "./egoi.server";
import { lerConfigWp, publicarOuActualizarLicaoEdicao } from "./wordpress.server";
import { caminhoCanonicoEdicao, criarBackup, gravarDestino } from "./revista/destinos.server";

export class ErroEnvio extends Error {
  status: number;
  constructor(mensagem: string, status = 400) {
    super(mensagem);
    this.status = status;
  }
}

export function admin(): SupabaseClient {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false },
  });
}

export interface Utilizador { id: string; nome: string; papel: "admin" | "curador" }

/** Confirma papel do utilizador autenticado; `real` exige admin. */
export async function autorizar(sb: SupabaseClient, userId: string, modo: "teste" | "real"): Promise<Utilizador> {
  const { data: perfil } = await sb.from("perfis").select("nome, papel").eq("id", userId).maybeSingle();
  const papel = (perfil?.papel ?? "") as string;
  if (papel !== "admin" && papel !== "curador") throw new ErroEnvio("Sem permissão", 403);
  if (modo === "real" && papel !== "admin") throw new ErroEnvio("Apenas o admin pode enviar para subscritores", 403);
  return { id: userId, nome: (perfil?.nome as string | null) ?? "utilizador", papel: papel as "admin" | "curador" };
}

async function credenciaisEgoi(sb: SupabaseClient) {
  const config = await lerConfig(sb);
  const apiKey = config.egoi_api_key || process.env.EGOI_API_KEY || "";
  const senderId = config.egoi_remetente_id || "";
  if (!apiKey) throw new ErroEnvio("Falta EGOI_API_KEY em Definições.");
  if (!senderId) throw new ErroEnvio("Falta o ID do remetente E-goi em Definições.");
  return { config, apiKey, senderId };
}

/* ─────────── preview ─────────── */

export async function previewHtml(edicaoId: string, destino: "email" | "wordpress") {
  if (destino === "wordpress") {
    const { html, resumoTexto } = await gerarHtmlEdicaoWeb(edicaoId);
    return { ok: true as const, destino, html, resumo: resumoTexto };
  }
  // Email: despacha por versão de template (clássico ou revista).
  const { html } = await renderEdicaoEmail(edicaoId);
  return { ok: true as const, destino, html, resumo: undefined as string | undefined };
}

/* ─────────── sincronizar rascunho ─────────── */

export async function sincronizarRascunho(userId: string, edicaoId: string, listaIds: string[]) {
  const sb = admin();
  const listasR = await resolverListas(sb, listaIds);
  if (!listasR.ok) throw new ErroEnvio(listasR.mensagem);
  const user = await autorizar(sb, userId, listasR.modo);
  const { apiKey, senderId } = await credenciaisEgoi(sb);

  const r = await sincronizar(sb, { edicaoId, listas: listasR.listas, apiKey, senderId, quem: user.nome });
  if (!r.ok) throw new ErroEnvio(r.mensagem, r.status);

  const sucessos = r.sinc.resultados.filter((x) => x.ok).length;
  const falhas = r.sinc.resultados.length - sucessos;
  return {
    ok: falhas === 0,
    campanhas: r.sinc.resultados,
    sucessos,
    falhas,
    mensagem: falhas === 0
      ? `E-goi actualizada em ${sucessos} lista(s).`
      : `E-goi: ${sucessos} ok · ${falhas} falha(s).`,
  };
}

/* ─────────── disparo ─────────── */

const DELAY_ENTRE_DISPAROS_MS = 15000;
/** Pausa entre preparar a campanha e dar a ordem de disparo dessa lista. */
const DELAY_ANTES_DISPARO_MS = 3000;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));


/** Próxima quinta-feira (inclusive hoje, se hoje for quinta). */
function proximaQuinta(): string {
  const hoje = new Date();
  const diff = (4 - hoje.getDay() + 7) % 7;
  const alvo = new Date(hoje);
  alvo.setDate(hoje.getDate() + diff);
  return alvo.toISOString().slice(0, 10);
}

/** Cria a edição seguinte em rascunho (idempotente: não cria se já houver rascunho). */
export async function garantirEdicaoSeguinte(sb: SupabaseClient, quem: string) {
  const { data: rasc } = await sb.from("edicoes").select("id").eq("estado", "rascunho").limit(1).maybeSingle();
  if (rasc) return null;

  const { data: max } = await sb.from("edicoes").select("numero").order("numero", { ascending: false }).limit(1).maybeSingle();
  const numero = ((max as { numero: number } | null)?.numero ?? 0) + 1;

  // As novas edições nascem no formato Revista (padrão actual).
  const { data: nova, error } = await sb.from("edicoes").insert({
    numero,
    data_envio_prevista: proximaQuinta(),
    assunto: `Edição #${numero}`,
    estado: "rascunho",
    bloco_livro: true,
    bloco_recursos: true,
    template_version: "revista",
  }).select("id").single();
  if (error || !nova) return null;

  await sb.from("cronicas").insert({ edicao_id: nova.id, conteudo: "", conteudo_html: "", leituras_recomendadas: "" });
  await sb.rpc("criar_seccoes_padrao", { _edicao_id: nova.id });
  await sb.from("revista_edicao").insert({ edicao_id: nova.id });
  await sb.from("audit_log").insert({ quem, accao: `Edição #${numero} criada automaticamente após o envio` });
  return { id: nova.id as string, numero };
}

/**
 * Marca a edição como enviada. Idempotente: se já estiver enviada não faz nada.
 * Verifica o resultado e regista falha no audit_log em vez de falhar em silêncio.
 */
export async function fecharEdicaoEnviada(sb: SupabaseClient, edicaoId: string, dados: {
  quem: string;
  assunto: string;
  html: string;
  sucessos: Array<{ campaign_hash?: string; lista_id: string; lista_nome: string }>;
  falhas: Array<{ lista_id: string; lista_nome: string; erro?: string }>;
}) {
  const { data: actual } = await sb.from("edicoes")
    .select("snapshot_envio, enviada_em, wordpress_post_id, wordpress_post_url").eq("id", edicaoId).maybeSingle();
  if (!actual) return false;
  // Idempotente pelo snapshot: o estado pode já ter sido marcado a meio do disparo.
  if ((actual as { snapshot_envio: unknown }).snapshot_envio) return true;

  const wp = actual as { enviada_em: string | null; wordpress_post_id: number | null; wordpress_post_url: string | null };
  const wpSnap = wp.wordpress_post_id
    ? { post_id: wp.wordpress_post_id, post_url: wp.wordpress_post_url ?? "", status: "publish" }
    : null;

  const { error, data: linhas } = await sb.from("edicoes").update({
    estado: "enviada",
    enviada_em: wp.enviada_em ?? new Date().toISOString(),
    snapshot_envio: {
      gerado_em: new Date().toISOString(),

      assunto: dados.assunto,
      html: dados.html,
      egoi: dados.sucessos.map((x) => ({ campaign_hash: x.campaign_hash, lista_id: x.lista_id, lista_nome: x.lista_nome })),
      egoi_falhas: dados.falhas.map((x) => ({ lista_id: x.lista_id, lista_nome: x.lista_nome, erro: x.erro })),
      wordpress: wpSnap,
    },
  }).eq("id", edicaoId).select("id");

  if (error || !linhas?.length) {
    await sb.from("audit_log").insert({
      quem: dados.quem,
      accao: "ERRO: a edição foi enviada mas não ficou marcada como enviada",
      detalhe: error?.message ?? "nenhuma linha actualizada",
    });
    return false;
  }

  await sb.from("noticias").update({ estado: "enviada" }).eq("edicao_id", edicaoId).eq("estado", "aprovada");
  await garantirEdicaoSeguinte(sb, dados.quem);
  return true;
}

export interface ResDisparo {
  lista_id: string;
  lista_nome: string;
  campaign_hash?: string;
  ok: boolean;
  erro?: string;
  sincronizada: boolean;
  /** Verdadeiro quando o estado veio da E-goi e não da resposta ao disparo. */
  confirmadoNaEgoi?: boolean;
}

/**
 * Pergunta à E-goi o estado real de cada campanha desta edição e alinha a
 * base de dados. Evita "por enviar" falso quando a resposta ao disparo se
 * perdeu (502, timeout) mas a campanha saiu mesmo.
 */
export async function reconciliarEdicao(edicaoId: string): Promise<{
  ok: true;
  actualizadas: Array<{ lista_id: string; lista_nome: string }>;
}> {
  const sb = admin();
  const { data: campsRaw } = await sb.from("egoi_campanhas")
    .select("lista_id, campaign_hash, estado, egoi_listas(nome)").eq("edicao_id", edicaoId);
  const camps = (campsRaw ?? []) as unknown as Array<{
    lista_id: string; campaign_hash: string; estado: string;
    egoi_listas: { nome: string } | { nome: string }[] | null;
  }>;
  const pendentes = camps.filter((c) => c.estado !== "enviada" && c.campaign_hash);
  if (!pendentes.length) return { ok: true, actualizadas: [] };

  let apiKey: string;
  try {
    ({ apiKey } = await credenciaisEgoi(sb));
  } catch {
    return { ok: true, actualizadas: [] };
  }

  const actualizadas: Array<{ lista_id: string; lista_nome: string }> = [];
  for (const c of pendentes) {
    const r = await estadoCampanha({ apiKey }, c.campaign_hash);
    if (!r.ok || r.estado !== "enviada") continue;
    await sb.from("egoi_campanhas")
      .update({ estado: "enviada", actualizado_em: new Date().toISOString() })
      .eq("edicao_id", edicaoId).eq("lista_id", c.lista_id);
    const rel = Array.isArray(c.egoi_listas) ? c.egoi_listas[0] : c.egoi_listas;
    const nome = rel?.nome ?? "lista";
    actualizadas.push({ lista_id: c.lista_id, lista_nome: nome });
    await sb.from("audit_log").insert({
      quem: "sistema",
      accao: `Estado alinhado com a E-goi: «${nome}» já tinha recebido esta edição`,
      detalhe: `campaign_hash ${c.campaign_hash}`,
    });
  }
  // Se a E-goi confirma envios, a edição já não pode voltar atrás.
  if (actualizadas.length) await bloquearSnapshotRevista(edicaoId);
  return { ok: true, actualizadas };
}


export interface ListaPreparada {
  lista_id: string;
  lista_nome: string;
  campaign_hash?: string;
  ok: boolean;
  erro?: string;
}

const LOCK_MS = 10 * 60_000;

/**
 * Prepara a edição Revista antes do envio: publica a versão web, guarda o URL
 * e grava a fotografia (dados + HTML + texto) no estado «preparado».
 *
 * «Preparado» garante determinismo — todas as listas recebem exactamente o
 * mesmo conteúdo — mas ainda é reversível: só bloqueia definitivamente quando
 * a primeira lista for aceite pela E-goi.
 * Não faz nada em edições Clássicas nem em edições já bloqueadas ou preparadas.
 */
async function prepararEdicaoRevista(
  sb: SupabaseClient,
  edicaoId: string,
  quem: string,
  listaIds: string[],
): Promise<void> {
  const { data: edRaw } = await sb.from("edicoes")
    .select("template_version").eq("id", edicaoId).maybeSingle();
  const ed = edRaw as { template_version?: string } | null;
  if (!ed || ed.template_version !== "revista") return;

  const existente = await lerSnapshotRevista(edicaoId);
  if (existente) return; // bloqueada (histórico) ou já preparada nesta tentativa

  await sb.from("audit_log").insert({ quem, accao: "Workflow Revista iniciado" });

  // 1) Prontidão completa ANTES de qualquer escrita externa. Os avisos não
  //    travam (a decisão é editorial, confirmada no modal); os bloqueios
  //    rígidos dos Briefs travam mesmo — nada segue para a E-goi.
  const { avaliarProntidao } = await import("./revista/prontidao.server");
  const pront = await avaliarProntidao(edicaoId, { listaIds });
  if (pront.bloqueiosRigidos.length) {
    await sb.from("audit_log").insert({
      quem,
      accao: "Envio Revista travado pelos Briefs",
      detalhe: pront.bloqueiosRigidos.join(" · ").slice(0, 500),
    });
    throw new ErroEnvio(pront.bloqueiosRigidos.join(" · "), 409);
  }
  await sb.from("audit_log").insert({
    quem,
    accao: pront.ok ? "Prontidão Revista verificada" : "Envio Revista prosseguiu com avisos",
    detalhe: pront.ok ? null : pront.bloqueios.join(" · ").slice(0, 500),
  });

  // 2) Briefs: publicar o que está pronto e confirmar que cada página responde
  //    ANTES de o endereço entrar no email. Com o interruptor desligado, nada
  //    disto corre.
  const { publicarBriefsDaEdicao, confirmarUrlsPublicas } = await import("./revista/brief/publicacao.server");
  const briefs = await publicarBriefsDaEdicao(edicaoId, sb);
  if (briefs.naoCongelaveis.length) {
    throw new ErroEnvio(
      `Não foi possível fixar a versão de ${briefs.naoCongelaveis.length} Brief(s): ${briefs.naoCongelaveis[0].motivo}`,
      409,
    );
  }
  const nLigacoes = Object.keys(briefs.ligacoes).length;
  if (nLigacoes > 0) {
    await sb.from("audit_log").insert({
      quem,
      accao: "Briefs publicados",
      detalhe: `${briefs.publicados} publicados · ${briefs.reutilizados} reutilizados`,
    });
    // 3) confirmação das páginas públicas — uma página nossa que não responde
    //    é bloqueio real: nunca entra um endereço morto no email.
    const confirmacao = await confirmarUrlsPublicas(briefs.ligacoes);
    await sb.from("audit_log").insert({
      quem,
      accao: confirmacao.ok ? "Endereços dos Briefs confirmados" : "Endereços de Brief sem resposta",
      detalhe: confirmacao.ok
        ? `${nLigacoes} páginas públicas`
        : confirmacao.falhados.map((f) => `${f.slug} (${f.status})`).join(" · ").slice(0, 500),
    });
    if (!confirmacao.ok) {
      throw new ErroEnvio(
        `Há páginas de Brief que não respondem: ${confirmacao.falhados.map((f) => f.slug).join(", ")}`,
        409,
      );
    }
  }

  // 4) a edição web canónica é a própria aplicação (/edicoes/:numero): não
  //    depende de nenhum CMS externo, por isso já está pronta aqui.
  const estrutura = await composeRevistaEdition(edicaoId, { ignorarSnapshot: true });
  await gravarDestino(edicaoId, "web", { estado: "preparada", url: caminhoCanonicoEdicao(estrutura.edicao.numero), erro: null }, sb);
  await sb.from("audit_log").insert({
    quem, accao: "Edição web preparada", detalhe: estrutura.urlPagina,
  });

  // 5) fotografia preparada — daqui em diante nada é recomposto.
  await prepararSnapshotRevista(edicaoId, estrutura, {
    emailHtml: montarHtmlRevista(estrutura),
    emailText: montarTextoRevista(estrutura),
    urlWeb: estrutura.urlPagina,
  });

  await sb.from("audit_log").insert({
    quem,
    accao: "Edição Revista preparada (fotografia guardada)",
    detalhe: estrutura.urlPagina,
  });

  // 6) publicação web: a página passa a responder já, antes do email. Fica
  //    fora dos motores de busca até a edição ser efectivamente enviada.
  await gravarDestino(edicaoId, "web", { estado: "publica", erro: null }, sb);
  await sb.from("audit_log").insert({
    quem, accao: "Edição web publicada (ainda fora dos motores de busca)", detalhe: estrutura.urlPagina,
  });

  // 7) confirmar que a página da edição responde antes de a anunciar no email.
  const web = await confirmarUrl(estrutura.urlPagina);
  await sb.from("audit_log").insert({
    quem,
    accao: web.ok ? "Endereço da edição web confirmado" : "Endereço da edição web sem resposta",
    detalhe: `${estrutura.urlPagina} (${web.status})`,
  });
  if (!web.ok) {
    throw new ErroEnvio(`A página da edição não responde (${web.status}). O envio foi travado.`, 409);
  }

  // 8) backup no WordPress — tolerante: nunca impede o envio.
  const backup = await criarBackup({ edicaoId, quem });
  await sb.from("audit_log").insert({
    quem,
    accao: backup.ok ? "Backup DigitalSprint.pt actualizado" : "Backup DigitalSprint.pt adiado (envio prossegue)",
    detalhe: backup.mensagem,
  });
}

/** HEAD com recurso a GET: confirma que um endereço nosso já responde. */
async function confirmarUrl(url: string): Promise<{ ok: boolean; status: number }> {
  try {
    let r = await fetch(url, { method: "HEAD", redirect: "follow" });
    if (r.status === 405 || r.status === 501) r = await fetch(url, { redirect: "follow" });
    return { ok: r.ok, status: r.status };
  } catch {
    return { ok: false, status: 0 };
  }
}



/**
 * Fase 1 — prepara todas as campanhas na E-goi (criar/actualizar rascunho)
 * ANTES de qualquer disparo. Nenhuma lista é enviada aqui.
 * Coloca também o bloqueio `envio_em_curso` para evitar disparos duplos.
 */
export async function prepararEnvio(opts: {
  userId?: string;
  quemNome?: string;
  edicaoId: string;
  listaIds: string[];
  confirmacaoNumero?: number;
  exigirConfirmacao?: boolean;
  publicarConteudos?: boolean;
}) {
  const sb = admin();
  const listasR = await resolverListas(sb, opts.listaIds);
  if (!listasR.ok) throw new ErroEnvio(listasR.mensagem);

  const quem = opts.userId
    ? (await autorizar(sb, opts.userId, listasR.modo)).nome
    : (opts.quemNome ?? "agendamento");

  const { apiKey, senderId } = await credenciaisEgoi(sb);

  const { data: edRaw } = await sb.from("edicoes")
    .select("numero, estado, assunto, envio_em_curso").eq("id", opts.edicaoId).maybeSingle();
  if (!edRaw) throw new ErroEnvio("Edição não encontrada", 404);
  const ed = edRaw as { numero: number; estado: string; assunto: string | null; envio_em_curso: string | null };
  if (ed.estado === "enviada") throw new ErroEnvio("Edição já foi enviada.", 409);
  if (listasR.modo === "real" && opts.exigirConfirmacao !== false && Number(opts.confirmacaoNumero ?? 0) !== ed.numero) {
    throw new ErroEnvio("Número de confirmação não corresponde à edição.");
  }
  if (listasR.modo === "real" && ed.envio_em_curso && Date.now() - new Date(ed.envio_em_curso).getTime() < LOCK_MS) {
    throw new ErroEnvio("Já existe um envio em curso para esta edição. Aguarda que termine.", 409);
  }
  const { data: formatoRaw } = await sb.from("edicoes")
    .select("template_version").eq("id", opts.edicaoId).maybeSingle();
  const revista = (formatoRaw as { template_version?: string } | null)?.template_version === "revista";

  if (revista && opts.publicarConteudos) {
    const { estadoDestinos } = await import("./revista/destinos.server");
    const { publicarArtigoCronica, actualizarArtigoCronica } = await import("./revista/frederico-wordpress.server");
    const antes = await estadoDestinos(opts.edicaoId);
    if (antes.cronica.estado !== "publicada" && antes.cronica.estado !== "manual") {
      const resultadoCronica = antes.cronica.estado === "desactualizada"
        ? await actualizarArtigoCronica({ edicaoId: opts.edicaoId, quem })
        : await publicarArtigoCronica({ edicaoId: opts.edicaoId, quem });
      if (!resultadoCronica.ok) {
        throw new ErroEnvio(`A crónica não ficou pública: ${resultadoCronica.mensagem}`, 409);
      }
    }
  }

  if (listasR.modo === "real") {
    await sb.from("edicoes").update({ envio_em_curso: new Date().toISOString() }).eq("id", opts.edicaoId);
  }
  // Nos testes Revista também se confirma a experiência pública completa.
  // A pessoa autorizou explicitamente esta publicação no modal; a versão web
  // permanece fora dos motores de busca até ao primeiro envio real.
  if (revista && opts.publicarConteudos) {
    await prepararEdicaoRevista(sb, opts.edicaoId, quem, listasR.listas.map((l) => l.id));
  } else if (revista && listasR.modo === "real") {
    await prepararEdicaoRevista(sb, opts.edicaoId, quem, listasR.listas.map((l) => l.id));
  }


  const listas: ListaPreparada[] = [];
  for (let i = 0; i < listasR.listas.length; i++) {
    const lista = listasR.listas[i];
    if (i > 0) await sleep(6000);
    const s = await sincronizarUmaLista(sb, { edicaoId: opts.edicaoId, lista, apiKey, senderId, quem, permitirEnviada: true });
    if (!s.ok) {
      listas.push({ lista_id: lista.id, lista_nome: lista.nome, ok: false, erro: s.mensagem });
      await sb.from("audit_log").insert({ quem, accao: `Erro a preparar campanha «${lista.nome}»`, detalhe: s.mensagem });
      continue;
    }
    const sr = s.resultado;
    listas.push({
      lista_id: lista.id,
      lista_nome: lista.nome,
      campaign_hash: sr.campaign_hash,
      ok: sr.ok && !!sr.campaign_hash,
      erro: sr.ok ? (sr.campaign_hash ? undefined : "Campanha sem identificador na E-goi") : sr.erro,
    });
  }

  return {
    ok: true as const,
    modo: listasR.modo,
    edicao: { numero: ed.numero, assunto: (ed.assunto ?? "").trim() || `Edição #${ed.numero}` },
    listas,
  };
}

/** Fase 2 — dispara uma única lista já preparada. */
export async function dispararLista(opts: {
  userId?: string;
  quemNome?: string;
  edicaoId: string;
  listaId: string;
}): Promise<ResDisparo> {
  const sb = admin();
  const listasR = await resolverListas(sb, [opts.listaId]);
  if (!listasR.ok) throw new ErroEnvio(listasR.mensagem);
  const lista = listasR.listas[0];

  const quem = opts.userId
    ? (await autorizar(sb, opts.userId, listasR.modo)).nome
    : (opts.quemNome ?? "agendamento");

  const { apiKey } = await credenciaisEgoi(sb);

  const { data: campRaw } = await sb.from("egoi_campanhas")
    .select("campaign_hash").eq("edicao_id", opts.edicaoId).eq("lista_id", lista.id).maybeSingle();
  const hash = (campRaw as { campaign_hash?: string } | null)?.campaign_hash;
  if (!hash) {
    return { lista_id: lista.id, lista_nome: lista.nome, ok: false, sincronizada: false, erro: "Campanha não preparada para esta lista." };
  }

  const { data: edRaw } = await sb.from("edicoes").select("numero").eq("id", opts.edicaoId).maybeSingle();
  const numero = (edRaw as { numero: number } | null)?.numero ?? 0;

  // Dá tempo à E-goi para consolidar o conteúdo antes da ordem de envio.
  await sleep(DELAY_ANTES_DISPARO_MS);
  const rD = await disparaCampanha({ apiKey }, hash, lista.egoi_lista_id);
  let confirmadoNaEgoi = false;
  if (!rD.ok) {
    // Um erro de rede/5xx não significa que a campanha não saiu: a E-goi é a
    // fonte da verdade. Só reportamos falha se ela confirmar que não enviou.
    const est = await estadoCampanha({ apiKey }, hash);
    if (est.ok && est.estado === "enviada") {
      confirmadoNaEgoi = true;
      await sb.from("audit_log").insert({
        quem,
        accao: `Disparo sem resposta para «${lista.nome}», mas a E-goi confirma o envio`,
        detalhe: `campaign_hash ${hash} · ${rD.mensagem}`,
      });
    } else {
      await sb.from("audit_log").insert({
        quem, accao: `Falha no disparo para «${lista.nome}»`, detalhe: `campaign_hash ${hash} · ${rD.mensagem}`,
      });
      return { lista_id: lista.id, lista_nome: lista.nome, ok: false, sincronizada: true, campaign_hash: hash, erro: rD.mensagem };
    }
  }

  await sb.from("egoi_campanhas")
    .update({ estado: "enviada", actualizado_em: new Date().toISOString() })
    .eq("edicao_id", opts.edicaoId).eq("lista_id", lista.id);
  // Primeira lista aceite pela E-goi: a fotografia passa a definitiva e as
  // listas em falta receberão obrigatoriamente esta mesma versão.
  if (listasR.modo === "real") await bloquearSnapshotRevista(opts.edicaoId);
  await sb.from("audit_log").insert({
    quem,
    accao: listasR.modo === "real"
      ? `Enviou a edição #${numero} para «${lista.nome}»${confirmadoNaEgoi ? " (confirmado na E-goi)" : ""}`
      : `Disparou teste da edição #${numero} para «${lista.nome}»`,
    detalhe: `campaign_hash ${hash}`,
  });

  return { lista_id: lista.id, lista_nome: lista.nome, ok: true, sincronizada: true, campaign_hash: hash, confirmadoNaEgoi };
}

/**
 * Repete apenas uma lista que falhou: volta a preparar a campanha e dispara.
 * Nunca reenvia uma lista cuja campanha já esteja marcada como enviada.
 */
export async function repetirLista(opts: {
  userId?: string;
  quemNome?: string;
  edicaoId: string;
  listaId: string;
}): Promise<ResDisparo> {
  const sb = admin();
  const listasR = await resolverListas(sb, [opts.listaId]);
  if (!listasR.ok) throw new ErroEnvio(listasR.mensagem);
  const lista = listasR.listas[0];

  const quem = opts.userId
    ? (await autorizar(sb, opts.userId, listasR.modo)).nome
    : (opts.quemNome ?? "repetição");

  // Antes de repetir, confirma na E-goi: se a campanha já saiu, repetir
  // duplicaria os emails.
  await reconciliarEdicao(opts.edicaoId);

  const { data: campRaw } = await sb.from("egoi_campanhas")
    .select("estado").eq("edicao_id", opts.edicaoId).eq("lista_id", lista.id).maybeSingle();
  if ((campRaw as { estado?: string } | null)?.estado === "enviada") {
    return {
      lista_id: lista.id, lista_nome: lista.nome, ok: false, sincronizada: true,
      erro: "Esta lista já recebeu esta edição — não foi repetida.",
    };
  }

  const { apiKey, senderId } = await credenciaisEgoi(sb);
  const s = await sincronizarUmaLista(sb, {
    edicaoId: opts.edicaoId, lista, apiKey, senderId, quem, permitirEnviada: true,
  });
  if (!s.ok) {
    await sb.from("audit_log").insert({ quem, accao: `Repetição falhou a preparar «${lista.nome}»`, detalhe: s.mensagem });
    return { lista_id: lista.id, lista_nome: lista.nome, ok: false, sincronizada: false, erro: s.mensagem };
  }
  if (!s.resultado.ok || !s.resultado.campaign_hash) {
    return {
      lista_id: lista.id, lista_nome: lista.nome, ok: false, sincronizada: false,
      erro: s.resultado.erro ?? "Campanha sem identificador na E-goi",
    };
  }

  await sb.from("audit_log").insert({ quem, accao: `Repetiu o envio da lista «${lista.nome}»` });
  return dispararLista({ userId: opts.userId, quemNome: opts.quemNome, edicaoId: opts.edicaoId, listaId: lista.id });
}

/** Fase 3 — liberta o bloqueio e fecha a edição (só em modo real e com sucessos). */
export async function finalizarEnvio(opts: {
  userId?: string;
  quemNome?: string;
  edicaoId: string;
  listaIds: string[];
  /** Quando há listas por repetir, liberta o bloqueio mas não fecha a edição. */
  adiarFecho?: boolean;
}) {

  const sb = admin();
  const listasR = await resolverListas(sb, opts.listaIds);
  if (!listasR.ok) throw new ErroEnvio(listasR.mensagem);
  const quem = opts.userId
    ? (await autorizar(sb, opts.userId, listasR.modo)).nome
    : (opts.quemNome ?? "agendamento");

  await sb.from("edicoes").update({ envio_em_curso: null }).eq("id", opts.edicaoId);
  if (listasR.modo !== "real") return { ok: true as const, fechada: false };
  // Com listas por repetir, a edição fica aberta para que a repetição consiga
  // voltar a preparar a campanha em falta.
  if (opts.adiarFecho) return { ok: true as const, fechada: false };


  const nomes = new Map(listasR.listas.map((l) => [l.id, l.nome]));
  const { data: campsRaw } = await sb.from("egoi_campanhas")
    .select("lista_id, campaign_hash, estado").eq("edicao_id", opts.edicaoId);
  const camps = (campsRaw ?? []) as { lista_id: string; campaign_hash: string; estado: string }[];
  const sucessos = camps
    .filter((c) => c.estado === "enviada" && nomes.has(c.lista_id))
    .map((c) => ({ campaign_hash: c.campaign_hash, lista_id: c.lista_id, lista_nome: nomes.get(c.lista_id)! }));
  if (!sucessos.length) {
    // Nenhuma lista aceite: a fotografia preparada é descartada e a edição
    // volta a ser editável para se corrigir e voltar a tentar.
    if (await descartarSnapshotPreparado(opts.edicaoId)) {
      await sb.from("audit_log").insert({
        quem,
        accao: "Envio sem sucesso — fotografia da edição descartada, edição de novo editável",
      });
    }
    // A página web preparada deixa de ser servida ao público. Os Briefs
    // mantêm estado, texto e histórico: ficam apenas sem edição pública.
    await gravarDestino(opts.edicaoId, "web", { estado: "preparada", erro: null }, sb);
    await sb.from("audit_log").insert({
      quem,
      accao: "Edição web despublicada — os Briefs mantêm-se, sem página pública",
    });
    return { ok: true as const, fechada: false };
  }

  const falhas = listasR.listas
    .filter((l) => !sucessos.some((s) => s.lista_id === l.id))
    .map((l) => ({ lista_id: l.id, lista_nome: l.nome }));

  const { data: edRaw } = await sb.from("edicoes").select("numero, assunto").eq("id", opts.edicaoId).maybeSingle();
  const ed = edRaw as { numero: number; assunto: string | null } | null;
  const assunto = (ed?.assunto ?? "").trim() || `Edição #${ed?.numero ?? ""}`;
  const { html } = await renderEdicaoEmail(opts.edicaoId);

  const fechada = await fecharEdicaoEnviada(sb, opts.edicaoId, { quem, assunto, html, sucessos, falhas });
  return { ok: true as const, fechada };
}

/**
 * Fluxo completo (usado pelo motor agendado e como alternativa ao fluxo
 * passo-a-passo do cockpit): prepara TODAS as campanhas, só depois dispara
 * lista a lista com pausa, e fecha a edição no fim.
 */
export async function dispararEgoi(opts: {
  userId?: string;
  quemNome?: string;
  edicaoId: string;
  listaIds: string[];
  confirmacaoNumero?: number;
  exigirConfirmacao?: boolean;
}) {
  const prep = await prepararEnvio(opts);

  const resultados: ResDisparo[] = [];
  let disparadas = 0;
  for (const l of prep.listas) {
    if (!l.ok) {
      resultados.push({ lista_id: l.lista_id, lista_nome: l.lista_nome, ok: false, erro: l.erro, sincronizada: false, campaign_hash: l.campaign_hash });
      continue;
    }
    if (disparadas > 0) await sleep(DELAY_ENTRE_DISPAROS_MS);
    disparadas++;
    resultados.push(await dispararLista({
      userId: opts.userId, quemNome: opts.quemNome, edicaoId: opts.edicaoId, listaId: l.lista_id,
    }));
  }

  await finalizarEnvio({ userId: opts.userId, quemNome: opts.quemNome, edicaoId: opts.edicaoId, listaIds: opts.listaIds });

  const sucessos = resultados.filter((r) => r.ok);
  const falhas = resultados.filter((r) => !r.ok);

  return {
    ok: sucessos.length > 0 && falhas.length === 0,
    modo: prep.modo,
    resultados,
    sucessos: sucessos.length,
    falhas: falhas.length,
    mensagem: falhas.length > 0
      ? `Enviada para ${sucessos.length} de ${prep.listas.length} lista(s); ${falhas.length} falha(s). ` +
        falhas.map((x) => `${x.lista_nome}: ${x.erro}`).join(" · ")
      : `Enviada para ${sucessos.length} lista(s).`,
  };
}

/* ─────────── WordPress ─────────── */

export async function publicarWordpress(opts: {
  edicaoId: string;
  userId?: string;
  quemNome?: string;
  /** Clássico publica; o backup Revista escreve em `private`. */
  status?: "draft" | "publish" | "private";
  /** Metadados Rank Math defensivos (noindex/canonical) — só no backup Revista. */
  meta?: Record<string, unknown>;
}) {
  const sb = admin();
  const quem = opts.userId ? (await autorizar(sb, opts.userId, "real")).nome : (opts.quemNome ?? "agendamento");

  const siteUrl = process.env.WORDPRESS_SITE_URL ?? "";
  const wpUser = process.env.WORDPRESS_APP_USER ?? "";
  const wpPass = process.env.WORDPRESS_APP_PASSWORD ?? "";
  if (!siteUrl || !wpUser || !wpPass) {
    throw new ErroEnvio("WordPress não configurado (falta WORDPRESS_SITE_URL, WORDPRESS_APP_USER ou WORDPRESS_APP_PASSWORD).");
  }

  const config = await lerConfig(sb);
  const wp = await publicarOuActualizarLicaoEdicao(sb, {
    edicaoId: opts.edicaoId,
    status: opts.status ?? "publish",
    meta: opts.meta,
    config: lerConfigWp(config),
    siteUrl, user: wpUser, password: wpPass,
    quem,
  });
  if (!wp.ok) throw new ErroEnvio(wp.mensagem, 502);

  return {
    ok: true as const,
    post_id: wp.post_id,
    post_url: wp.post_url,
    status: wp.status,
    actualizada: wp.actualizada,
    mensagem: wp.actualizada ? "Página actualizada no WordPress ✓" : "Página escrita no WordPress ✓",
  };
}
