import { describe, expect, it } from "vitest";
import { geometria, normalizarEnquadramento } from "../recorte-imagem";

describe("recorte da imagem da crónica", () => {
  it("por defeito centra e preenche a faixa", () => {
    const e = normalizarEnquadramento({});
    const g = geometria(2000, 1000, 1112, 400, e);
    expect(g.dw).toBeGreaterThanOrEqual(1112);
    expect(g.dh).toBeGreaterThanOrEqual(400);
    expect(g.left).toBeCloseTo((1112 - g.dw) / 2);
  });
  it("nunca deixa bordas vazias mesmo nos extremos", () => {
    const g = geometria(2000, 2000, 1112, 400, { x: 0, y: 1, zoom: 1 });
    expect(g.left).toBe(0);
    expect(g.top + g.dh).toBeCloseTo(400);
  });
});
