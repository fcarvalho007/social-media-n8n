// Camada de dados do formato Revista (cliente). Não toca no sistema clássico.

import { supabase } from "@/integrations/supabase/client";
import { carregarNoticiasDaEdicao } from "@/lib/newsletter-engine/revista/universo";
import { LIMITES_REVISTA, ROTULOS_REVISTA } from "@/lib/newsletter-engine/revista/rotulos";
import { VALORES_NOVA_EDICAO_REVISTA } from "./valores-habituais";


export type PapelRevista = "destaque" | "radar";

const MAXIMOS: Record<PapelRevista, number> = {
  destaque: LIMITES_REVISTA.destaquesMax,
  radar: LIMITES_REVISTA.radarMax,
};

export interface ConfigRevista {
  edicao_id: string;
  preheader: string;
  promocao_activa: boolean;
  promocao_prefixo: string;
  promocao_link_texto: string;
  promocao_url: string;
  cronica_titulo: string;
  cronica_subtitulo: string;
  cronica_lede: string;
  cronica_excerto: string;
  cronica_url: string;
  momento_activo: boolean;
  momento_etiqueta: string;
  momento_valor: string;
  momento_descricao: string;
  pull_quote: string;
  momento_posicao: number;
  pull_quote_posicao: number;
  cronica_lede_posicao: number;

  cronica_imagem_url: string;
  cronica_imagem_alt: string;
  cronica_imagem_credito: string;
  cronica_imagem_credito_url: string;
  cronica_imagem_fonte: string;
  cronica_imagem_posicao: number;
  cronica_imagem_recorte_url: string;
  cronica_imagem_enquadramento: EnquadramentoImagem;

  recomendacao_tipo: string;
  recomendacao_meta: string;
  recomendacao_titulo: string;
  recomendacao_url: string;
  recomendacao_nota: string;
  recomendacao_activa: boolean;
  bloco_ferramentas: boolean;
  podcast_activo: boolean;
  podcast_etiqueta: string;
  podcast_programa: string;
  podcast_tema: string;
  podcast_convidado: string;
  podcast_pergunta: string;
  podcast_url: string;
  podcast_cta: string;
  livro_activo: boolean;
  livro_etiqueta: string;
  livro_titulo: string;
  livro_texto: string;
  livro_cta: string;
  livro_url: string;
  servicos_activo: boolean;
  servicos_cursos_activo: boolean;
  servicos_consultoria_activo: boolean;
  servicos_auditoria_activo: boolean;
  servicos_titulo: string;
  servicos_intro: string;
  servicos_cta: string;
  servicos_url: string;
  servicos_consultoria_texto: string;
  servicos_consultoria_cta: string;
  servicos_consultoria_url: string;
  servicos_cursos_texto: string;
  servicos_cursos_cta: string;
  servicos_cursos_url: string;
}

export interface ItemRevista {
  id: string;
  edicao_id: string;
  noticia_id: string;
  papel: PapelRevista;
  ordem: number;
  titulo_override: string | null;
  resumo_factual: string;
  minha_leitura: string;
  cta_rotulo: string;
  radar_nota: string;
  noticia: {
    id: string;
    titulo: string;
    descricao: string | null;
    url: string | null;
    url_curto: string | null;
    categoria: string;
  } | null;
}

export interface NoticiaAprovada {
  id: string;
  titulo: string;
  descricao: string | null;
  url: string | null;
  url_curto: string | null;
  categoria: string;
  ordem: number | null;
}

export async function getConfigRevista(edicaoId: string): Promise<ConfigRevista> {
  const { data, error } = await supabase
    .from("revista_edicao").select("*").eq("edicao_id", edicaoId).maybeSingle();
  if (error) throw error;
  if (data) return data as ConfigRevista;
  // Os blocos fixos (livro e serviços) nascem preenchidos: ligados sem
  // conteúdo não apareceriam na pré-visualização.
  const { data: novo, error: e2 } = await supabase
    .from("revista_edicao")
    .insert({ edicao_id: edicaoId, ...VALORES_NOVA_EDICAO_REVISTA })
    .select("*").single();

  if (e2) throw e2;
  return novo as ConfigRevista;
}

export async function guardarConfigRevista(
  edicaoId: string, patch: Partial<Omit<ConfigRevista, "edicao_id">>,
): Promise<void> {
  const { error } = await supabase.from("revista_edicao").update(patch).eq("edicao_id", edicaoId);
  if (error) throw error;
}

export async function getItensRevista(edicaoId: string): Promise<ItemRevista[]> {
  const { data, error } = await supabase
    .from("revista_itens")
    .select("*, noticia:noticias(id, titulo, descricao, url, url_curto, categoria)")
    .eq("edicao_id", edicaoId)
    .order("ordem", { ascending: true });
  if (error) throw error;
  return (data ?? []).map((r) => ({
    ...r,
    noticia: Array.isArray(r.noticia) ? (r.noticia[0] ?? null) : r.noticia,
  })) as ItemRevista[];
}

/**
 * Universo único de notícias da edição — mesma definição usada pelo composer,
 * pelo cálculo de «Só site», pelos contadores e pela versão web.
 */
export async function getAprovadasDaEdicao(edicaoId: string): Promise<NoticiaAprovada[]> {
  const linhas = await carregarNoticiasDaEdicao(supabase as never, edicaoId);
  return linhas as unknown as NoticiaAprovada[];
}



export async function adicionarItem(
  edicaoId: string, noticiaId: string, papel: PapelRevista,
): Promise<void> {
  const itens = await getItensRevista(edicaoId);
  if (itens.some((i) => i.noticia_id === noticiaId)) {
    throw new Error("Essa notícia já está a ser usada nesta edição.");
  }
  const doPapel = itens.filter((i) => i.papel === papel);
  if (doPapel.length >= MAXIMOS[papel]) {
    throw new Error(papel === "destaque"
      ? `«${ROTULOS_REVISTA.destaques}» já tem ${LIMITES_REVISTA.destaquesMax} notícias.`
      : `O Radar já tem ${LIMITES_REVISTA.radarMax} notícias.`);
  }
  const noticia = (await supabase
    .from("noticias").select("descricao").eq("id", noticiaId).maybeSingle()).data;
  const { error } = await supabase.from("revista_itens").insert({
    edicao_id: edicaoId,
    noticia_id: noticiaId,
    papel,
    ordem: doPapel.length,
    resumo_factual: papel === "destaque" ? ((noticia?.descricao ?? "") as string) : "",
  });
  if (error) throw error;
}

export async function removerItem(itemId: string): Promise<void> {
  const { error } = await supabase.from("revista_itens").delete().eq("id", itemId);
  if (error) throw error;
}

export async function actualizarItem(
  itemId: string,
  patch: Partial<Pick<ItemRevista, "titulo_override" | "resumo_factual" | "minha_leitura" | "cta_rotulo" | "radar_nota">>,
): Promise<void> {
  const { error } = await supabase.from("revista_itens").update(patch).eq("id", itemId);
  if (error) throw error;
}

/** Move um item entre secções, respeitando os limites e sem duplicar. */
export async function moverItemPapel(
  edicaoId: string, itemId: string, papel: PapelRevista,
): Promise<void> {
  const itens = await getItensRevista(edicaoId);
  const doPapel = itens.filter((i) => i.papel === papel && i.id !== itemId);
  if (doPapel.length >= MAXIMOS[papel]) {
    throw new Error(papel === "destaque"
      ? `«${ROTULOS_REVISTA.destaques}» já tem ${LIMITES_REVISTA.destaquesMax} notícias.`
      : `O Radar já tem ${LIMITES_REVISTA.radarMax} notícias.`);
  }
  const { error } = await supabase
    .from("revista_itens").update({ papel, ordem: doPapel.length }).eq("id", itemId);
  if (error) throw error;
}

export async function reordenarItens(ids: string[]): Promise<void> {
  await Promise.all(ids.map((id, i) =>
    supabase.from("revista_itens").update({ ordem: i }).eq("id", id)));
}

/** Enquadramento da faixa da imagem da crónica: centro (0–1) e zoom (≥1). */
export type EnquadramentoImagem = { x?: number; y?: number; zoom?: number };
