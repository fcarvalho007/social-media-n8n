export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          accao: string
          criado_em: string
          detalhe: Json | null
          id: number
          quem: string | null
        }
        Insert: {
          accao: string
          criado_em?: string
          detalhe?: Json | null
          id?: never
          quem?: string | null
        }
        Update: {
          accao?: string
          criado_em?: string
          detalhe?: Json | null
          id?: never
          quem?: string | null
        }
        Relationships: []
      }
      brief_edicoes: {
        Row: {
          brief_id: string
          created_at: string
          edicao_id: string
          id: string
          ordem: number
          papel: string
          titulo_apresentado: string | null
        }
        Insert: {
          brief_id: string
          created_at?: string
          edicao_id: string
          id?: string
          ordem?: number
          papel?: string
          titulo_apresentado?: string | null
        }
        Update: {
          brief_id?: string
          created_at?: string
          edicao_id?: string
          id?: string
          ordem?: number
          papel?: string
          titulo_apresentado?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "brief_edicoes_brief_id_fkey"
            columns: ["brief_id"]
            isOneToOne: false
            referencedRelation: "briefs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "brief_edicoes_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
      brief_eventos: {
        Row: {
          actualizado_em: string
          brief_slug: string
          contagem: number
          dia: string
          edicao_numero: number | null
          evento: string
          id: string
        }
        Insert: {
          actualizado_em?: string
          brief_slug?: string
          contagem?: number
          dia?: string
          edicao_numero?: number | null
          evento: string
          id?: string
        }
        Update: {
          actualizado_em?: string
          brief_slug?: string
          contagem?: number
          dia?: string
          edicao_numero?: number | null
          evento?: string
          id?: string
        }
        Relationships: []
      }
      brief_versoes: {
        Row: {
          brief_id: string
          conteudo: Json
          criado_em: string
          criado_por: string | null
          hash: string
          id: string
          motivo: string | null
          versao: number
        }
        Insert: {
          brief_id: string
          conteudo?: Json
          criado_em?: string
          criado_por?: string | null
          hash: string
          id?: string
          motivo?: string | null
          versao: number
        }
        Update: {
          brief_id?: string
          conteudo?: Json
          criado_em?: string
          criado_por?: string | null
          hash?: string
          id?: string
          motivo?: string | null
          versao?: number
        }
        Relationships: [
          {
            foreignKeyName: "brief_versoes_brief_id_fkey"
            columns: ["brief_id"]
            isOneToOne: false
            referencedRelation: "briefs"
            referencedColumns: ["id"]
          },
        ]
      }
      briefs: {
        Row: {
          aprovada_em: string | null
          aprovada_por: string | null
          contexto: Json
          created_at: string
          em_30_segundos: Json
          erro: string | null
          estado: string
          factos: Json
          fingerprint: string
          fonte_data: string | null
          fonte_primaria_url: string | null
          fonte_publisher: string | null
          fonte_url: string | null
          fonte_url_norm: string | null
          fontes_adicionais: Json
          hash_publicado: string | null
          ia: Json
          id: string
          incertezas: Json
          indexavel: boolean
          leitura_aprovada: string
          leitura_sugerida: string
          noticia_id: string | null
          porque_interessa: Json
          publicado_em: string | null
          pull_quote_sugerida: string
          slug: string
          slug_congelado: boolean
          tentativas: number
          tese_editorial: string
          tipo: string
          titulo_editorial: string
          updated_at: string
          verificacao: Json
        }
        Insert: {
          aprovada_em?: string | null
          aprovada_por?: string | null
          contexto?: Json
          created_at?: string
          em_30_segundos?: Json
          erro?: string | null
          estado?: string
          factos?: Json
          fingerprint: string
          fonte_data?: string | null
          fonte_primaria_url?: string | null
          fonte_publisher?: string | null
          fonte_url?: string | null
          fonte_url_norm?: string | null
          fontes_adicionais?: Json
          hash_publicado?: string | null
          ia?: Json
          id?: string
          incertezas?: Json
          indexavel?: boolean
          leitura_aprovada?: string
          leitura_sugerida?: string
          noticia_id?: string | null
          porque_interessa?: Json
          publicado_em?: string | null
          pull_quote_sugerida?: string
          slug: string
          slug_congelado?: boolean
          tentativas?: number
          tese_editorial?: string
          tipo?: string
          titulo_editorial?: string
          updated_at?: string
          verificacao?: Json
        }
        Update: {
          aprovada_em?: string | null
          aprovada_por?: string | null
          contexto?: Json
          created_at?: string
          em_30_segundos?: Json
          erro?: string | null
          estado?: string
          factos?: Json
          fingerprint?: string
          fonte_data?: string | null
          fonte_primaria_url?: string | null
          fonte_publisher?: string | null
          fonte_url?: string | null
          fonte_url_norm?: string | null
          fontes_adicionais?: Json
          hash_publicado?: string | null
          ia?: Json
          id?: string
          incertezas?: Json
          indexavel?: boolean
          leitura_aprovada?: string
          leitura_sugerida?: string
          noticia_id?: string | null
          porque_interessa?: Json
          publicado_em?: string | null
          pull_quote_sugerida?: string
          slug?: string
          slug_congelado?: boolean
          tentativas?: number
          tese_editorial?: string
          tipo?: string
          titulo_editorial?: string
          updated_at?: string
          verificacao?: Json
        }
        Relationships: [
          {
            foreignKeyName: "briefs_noticia_id_fkey"
            columns: ["noticia_id"]
            isOneToOne: false
            referencedRelation: "noticias"
            referencedColumns: ["id"]
          },
        ]
      }
      configuracoes: {
        Row: {
          actualizado_em: string
          chave: string
          valor: string | null
        }
        Insert: {
          actualizado_em?: string
          chave: string
          valor?: string | null
        }
        Update: {
          actualizado_em?: string
          chave?: string
          valor?: string | null
        }
        Relationships: []
      }
      cronicas: {
        Row: {
          busca: unknown
          concluida: boolean
          conteudo: string | null
          conteudo_html: string | null
          edicao_id: string
          id: string
          leituras_recomendadas: string | null
          titulo: string | null
          updated_at: string
        }
        Insert: {
          busca?: unknown
          concluida?: boolean
          conteudo?: string | null
          conteudo_html?: string | null
          edicao_id: string
          id?: string
          leituras_recomendadas?: string | null
          titulo?: string | null
          updated_at?: string
        }
        Update: {
          busca?: unknown
          concluida?: boolean
          conteudo?: string | null
          conteudo_html?: string | null
          edicao_id?: string
          id?: string
          leituras_recomendadas?: string | null
          titulo?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cronicas_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: true
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
      curadoria_config: {
        Row: {
          actualizado_em: string
          id: number
          janela_horas: number
          max_insercoes_por_corrida: number
          max_por_categoria: number
          max_por_dia: number
          max_por_dia_email: number
          max_por_email: number
          max_por_fonte: number
        }
        Insert: {
          actualizado_em?: string
          id?: number
          janela_horas?: number
          max_insercoes_por_corrida?: number
          max_por_categoria?: number
          max_por_dia?: number
          max_por_dia_email?: number
          max_por_email?: number
          max_por_fonte?: number
        }
        Update: {
          actualizado_em?: string
          id?: number
          janela_horas?: number
          max_insercoes_por_corrida?: number
          max_por_categoria?: number
          max_por_dia?: number
          max_por_dia_email?: number
          max_por_email?: number
          max_por_fonte?: number
        }
        Relationships: []
      }
      curadoria_ferramentas_config: {
        Row: {
          activo: boolean
          actualizado_em: string
          dia_semana: number
          hora: number
          id: number
          max_por_corrida: number
        }
        Insert: {
          activo?: boolean
          actualizado_em?: string
          dia_semana?: number
          hora?: number
          id?: number
          max_por_corrida?: number
        }
        Update: {
          activo?: boolean
          actualizado_em?: string
          dia_semana?: number
          hora?: number
          id?: number
          max_por_corrida?: number
        }
        Relationships: []
      }
      curadoria_fila: {
        Row: {
          created_at: string
          descricao: string
          email_recebido_id: string | null
          estado: string
          fonte_grupo: string | null
          fonte_id: string | null
          fonte_nome: string | null
          id: string
          motivo: string | null
          noticia_id: string | null
          origem: string
          publicado_em: string
          tentativas: number
          titulo: string
          updated_at: string
          url: string | null
          url_norm: string | null
        }
        Insert: {
          created_at?: string
          descricao?: string
          email_recebido_id?: string | null
          estado?: string
          fonte_grupo?: string | null
          fonte_id?: string | null
          fonte_nome?: string | null
          id?: string
          motivo?: string | null
          noticia_id?: string | null
          origem?: string
          publicado_em?: string
          tentativas?: number
          titulo: string
          updated_at?: string
          url?: string | null
          url_norm?: string | null
        }
        Update: {
          created_at?: string
          descricao?: string
          email_recebido_id?: string | null
          estado?: string
          fonte_grupo?: string | null
          fonte_id?: string | null
          fonte_nome?: string | null
          id?: string
          motivo?: string | null
          noticia_id?: string | null
          origem?: string
          publicado_em?: string
          tentativas?: number
          titulo?: string
          updated_at?: string
          url?: string | null
          url_norm?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "curadoria_fila_email_recebido_id_fkey"
            columns: ["email_recebido_id"]
            isOneToOne: false
            referencedRelation: "emails_recebidos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "curadoria_fila_fonte_id_fkey"
            columns: ["fonte_id"]
            isOneToOne: false
            referencedRelation: "fontes_curadoria"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "curadoria_fila_noticia_id_fkey"
            columns: ["noticia_id"]
            isOneToOne: false
            referencedRelation: "noticias"
            referencedColumns: ["id"]
          },
        ]
      }
      definicoes_ia: {
        Row: {
          actualizado_por: string | null
          created_at: string
          estado: string
          id: string
          modelo: string
          provider: string
          ultimo_erro: string | null
          ultimo_teste_em: string | null
          updated_at: string
        }
        Insert: {
          actualizado_por?: string | null
          created_at?: string
          estado?: string
          id?: string
          modelo?: string
          provider?: string
          ultimo_erro?: string | null
          ultimo_teste_em?: string | null
          updated_at?: string
        }
        Update: {
          actualizado_por?: string | null
          created_at?: string
          estado?: string
          id?: string
          modelo?: string
          provider?: string
          ultimo_erro?: string | null
          ultimo_teste_em?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      edicoes: {
        Row: {
          agendado_para: string | null
          agendado_por: string | null
          agendamento_erro: string | null
          agendamento_estado: string
          agendamento_iniciado_em: string | null
          agendamento_listas: Json
          agendamento_wordpress: boolean
          assunto: string | null
          bloco_consultoria: Json
          bloco_livro: boolean
          bloco_recursos: boolean
          categorias_ocultas_email: Json
          created_at: string
          data_envio_prevista: string | null
          descricoes_ajustadas_em: string | null
          destinos: Json
          enviada_em: string | null
          envio_em_curso: string | null
          episodio_podcast_id: string | null
          estado: string
          id: string
          links_ignorados: Json
          links_verificados: Json | null
          links_verificados_em: string | null
          numero: number
          revista_snapshot: Json | null
          snapshot_envio: Json | null
          template_version: string
          wordpress_post_id: number | null
          wordpress_post_url: string | null
        }
        Insert: {
          agendado_para?: string | null
          agendado_por?: string | null
          agendamento_erro?: string | null
          agendamento_estado?: string
          agendamento_iniciado_em?: string | null
          agendamento_listas?: Json
          agendamento_wordpress?: boolean
          assunto?: string | null
          bloco_consultoria?: Json
          bloco_livro?: boolean
          bloco_recursos?: boolean
          categorias_ocultas_email?: Json
          created_at?: string
          data_envio_prevista?: string | null
          descricoes_ajustadas_em?: string | null
          destinos?: Json
          enviada_em?: string | null
          envio_em_curso?: string | null
          episodio_podcast_id?: string | null
          estado?: string
          id?: string
          links_ignorados?: Json
          links_verificados?: Json | null
          links_verificados_em?: string | null
          numero: number
          revista_snapshot?: Json | null
          snapshot_envio?: Json | null
          template_version?: string
          wordpress_post_id?: number | null
          wordpress_post_url?: string | null
        }
        Update: {
          agendado_para?: string | null
          agendado_por?: string | null
          agendamento_erro?: string | null
          agendamento_estado?: string
          agendamento_iniciado_em?: string | null
          agendamento_listas?: Json
          agendamento_wordpress?: boolean
          assunto?: string | null
          bloco_consultoria?: Json
          bloco_livro?: boolean
          bloco_recursos?: boolean
          categorias_ocultas_email?: Json
          created_at?: string
          data_envio_prevista?: string | null
          descricoes_ajustadas_em?: string | null
          destinos?: Json
          enviada_em?: string | null
          envio_em_curso?: string | null
          episodio_podcast_id?: string | null
          estado?: string
          id?: string
          links_ignorados?: Json
          links_verificados?: Json | null
          links_verificados_em?: string | null
          numero?: number
          revista_snapshot?: Json | null
          snapshot_envio?: Json | null
          template_version?: string
          wordpress_post_id?: number | null
          wordpress_post_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "edicoes_episodio_podcast_id_fkey"
            columns: ["episodio_podcast_id"]
            isOneToOne: false
            referencedRelation: "episodios_podcast"
            referencedColumns: ["id"]
          },
        ]
      }
      egoi_campanhas: {
        Row: {
          actualizado_em: string
          campaign_hash: string
          criado_em: string
          edicao_id: string
          estado: string
          id: string
          lista_id: string
        }
        Insert: {
          actualizado_em?: string
          campaign_hash: string
          criado_em?: string
          edicao_id: string
          estado?: string
          id?: string
          lista_id: string
        }
        Update: {
          actualizado_em?: string
          campaign_hash?: string
          criado_em?: string
          edicao_id?: string
          estado?: string
          id?: string
          lista_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "egoi_campanhas_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "egoi_campanhas_lista_id_fkey"
            columns: ["lista_id"]
            isOneToOne: false
            referencedRelation: "egoi_listas"
            referencedColumns: ["id"]
          },
        ]
      }
      egoi_listas: {
        Row: {
          activa: boolean
          created_at: string
          egoi_lista_id: string
          id: string
          nome: string
          ordem: number
          tipo: string
        }
        Insert: {
          activa?: boolean
          created_at?: string
          egoi_lista_id: string
          id?: string
          nome: string
          ordem?: number
          tipo?: string
        }
        Update: {
          activa?: boolean
          created_at?: string
          egoi_lista_id?: string
          id?: string
          nome?: string
          ordem?: number
          tipo?: string
        }
        Relationships: []
      }
      emails_recebidos: {
        Row: {
          assunto: string | null
          classificacao: string | null
          classificacao_detalhe: Json
          corpo_hash: string | null
          corpo_html: string | null
          corpo_texto: string | null
          id: string
          message_id: string | null
          notas_processadas: number
          processado_em: string | null
          processamento_erro: string | null
          processamento_estado: string
          processamento_tentativas: number
          recebido_em: string
          remetente: string | null
          remetente_nome: string | null
        }
        Insert: {
          assunto?: string | null
          classificacao?: string | null
          classificacao_detalhe?: Json
          corpo_hash?: string | null
          corpo_html?: string | null
          corpo_texto?: string | null
          id?: string
          message_id?: string | null
          notas_processadas?: number
          processado_em?: string | null
          processamento_erro?: string | null
          processamento_estado?: string
          processamento_tentativas?: number
          recebido_em?: string
          remetente?: string | null
          remetente_nome?: string | null
        }
        Update: {
          assunto?: string | null
          classificacao?: string | null
          classificacao_detalhe?: Json
          corpo_hash?: string | null
          corpo_html?: string | null
          corpo_texto?: string | null
          id?: string
          message_id?: string | null
          notas_processadas?: number
          processado_em?: string | null
          processamento_erro?: string | null
          processamento_estado?: string
          processamento_tentativas?: number
          recebido_em?: string
          remetente?: string | null
          remetente_nome?: string | null
        }
        Relationships: []
      }
      episodios_podcast: {
        Row: {
          codigo: string | null
          criado_em: string
          data_publicacao: string | null
          id: string
          titulo: string
          url: string | null
        }
        Insert: {
          codigo?: string | null
          criado_em?: string
          data_publicacao?: string | null
          id?: string
          titulo: string
          url?: string | null
        }
        Update: {
          codigo?: string | null
          criado_em?: string
          data_publicacao?: string | null
          id?: string
          titulo?: string
          url?: string | null
        }
        Relationships: []
      }
      ferramentas_excluidas: {
        Row: {
          criado_em: string
          dominio: string | null
          id: string
          motivo: string | null
          nome_norm: string | null
        }
        Insert: {
          criado_em?: string
          dominio?: string | null
          id?: string
          motivo?: string | null
          nome_norm?: string | null
        }
        Update: {
          criado_em?: string
          dominio?: string | null
          id?: string
          motivo?: string | null
          nome_norm?: string | null
        }
        Relationships: []
      }
      ferramentas_semana: {
        Row: {
          cor: string
          created_at: string
          cta_rotulo: string
          descricao: string | null
          edicao_id: string
          emoji: string | null
          etiqueta: string
          id: string
          nome: string | null
          posicao: number
          updated_at: string
          url: string | null
        }
        Insert: {
          cor?: string
          created_at?: string
          cta_rotulo?: string
          descricao?: string | null
          edicao_id: string
          emoji?: string | null
          etiqueta?: string
          id?: string
          nome?: string | null
          posicao: number
          updated_at?: string
          url?: string | null
        }
        Update: {
          cor?: string
          created_at?: string
          cta_rotulo?: string
          descricao?: string | null
          edicao_id?: string
          emoji?: string | null
          etiqueta?: string
          id?: string
          nome?: string | null
          posicao?: number
          updated_at?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ferramentas_semana_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
      ferramentas_sugeridas: {
        Row: {
          aprovada_em: string | null
          assunto_origem: string | null
          categoria: string | null
          cor: string
          criado_em: string
          descricao: string | null
          descricao_original: string | null
          edicao_aprovada_id: string | null
          edicao_usada_id: string | null
          emoji: string | null
          estado: string
          fonte_directorio_id: string | null
          fonte_email_id: string | null
          id: string
          nome: string
          remetente: string | null
          updated_at: string
          url: string
        }
        Insert: {
          aprovada_em?: string | null
          assunto_origem?: string | null
          categoria?: string | null
          cor?: string
          criado_em?: string
          descricao?: string | null
          descricao_original?: string | null
          edicao_aprovada_id?: string | null
          edicao_usada_id?: string | null
          emoji?: string | null
          estado?: string
          fonte_directorio_id?: string | null
          fonte_email_id?: string | null
          id?: string
          nome: string
          remetente?: string | null
          updated_at?: string
          url: string
        }
        Update: {
          aprovada_em?: string | null
          assunto_origem?: string | null
          categoria?: string | null
          cor?: string
          criado_em?: string
          descricao?: string | null
          descricao_original?: string | null
          edicao_aprovada_id?: string | null
          edicao_usada_id?: string | null
          emoji?: string | null
          estado?: string
          fonte_directorio_id?: string | null
          fonte_email_id?: string | null
          id?: string
          nome?: string
          remetente?: string | null
          updated_at?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "ferramentas_sugeridas_edicao_aprovada_id_fkey"
            columns: ["edicao_aprovada_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferramentas_sugeridas_edicao_usada_id_fkey"
            columns: ["edicao_usada_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferramentas_sugeridas_fonte_directorio_id_fkey"
            columns: ["fonte_directorio_id"]
            isOneToOne: false
            referencedRelation: "fontes_curadoria"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferramentas_sugeridas_fonte_email_id_fkey"
            columns: ["fonte_email_id"]
            isOneToOne: false
            referencedRelation: "emails_recebidos"
            referencedColumns: ["id"]
          },
        ]
      }
      fontes_curadoria: {
        Row: {
          activa: boolean
          created_at: string
          criada_em: string
          foca_ferramentas: boolean
          grupo: string | null
          id: string
          nome: string
          remetente_dominio: string | null
          remetente_email: string | null
          tipo: string
          ultima_recolha: string | null
          url_feed: string
          url_listagem: string | null
          zeros_consecutivos: number
        }
        Insert: {
          activa?: boolean
          created_at?: string
          criada_em?: string
          foca_ferramentas?: boolean
          grupo?: string | null
          id?: string
          nome: string
          remetente_dominio?: string | null
          remetente_email?: string | null
          tipo?: string
          ultima_recolha?: string | null
          url_feed: string
          url_listagem?: string | null
          zeros_consecutivos?: number
        }
        Update: {
          activa?: boolean
          created_at?: string
          criada_em?: string
          foca_ferramentas?: boolean
          grupo?: string | null
          id?: string
          nome?: string
          remetente_dominio?: string | null
          remetente_email?: string | null
          tipo?: string
          ultima_recolha?: string | null
          url_feed?: string
          url_listagem?: string | null
          zeros_consecutivos?: number
        }
        Relationships: []
      }
      ia_uso: {
        Row: {
          brief_id: string | null
          criado_em: string
          custo_usd: number
          duracao_ms: number | null
          edicao_id: string | null
          erro: string | null
          id: string
          modelo: string
          operacao: string | null
          origem: string
          sucesso: boolean
          tokens_entrada_cache_hit: number
          tokens_entrada_cache_miss: number
          tokens_saida: number
        }
        Insert: {
          brief_id?: string | null
          criado_em?: string
          custo_usd?: number
          duracao_ms?: number | null
          edicao_id?: string | null
          erro?: string | null
          id?: string
          modelo: string
          operacao?: string | null
          origem: string
          sucesso?: boolean
          tokens_entrada_cache_hit?: number
          tokens_entrada_cache_miss?: number
          tokens_saida?: number
        }
        Update: {
          brief_id?: string | null
          criado_em?: string
          custo_usd?: number
          duracao_ms?: number | null
          edicao_id?: string | null
          erro?: string | null
          id?: string
          modelo?: string
          operacao?: string | null
          origem?: string
          sucesso?: boolean
          tokens_entrada_cache_hit?: number
          tokens_entrada_cache_miss?: number
          tokens_saida?: number
        }
        Relationships: [
          {
            foreignKeyName: "ia_uso_brief_id_fkey"
            columns: ["brief_id"]
            isOneToOne: false
            referencedRelation: "briefs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ia_uso_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
      noticias: {
        Row: {
          busca: unknown
          categoria: string
          corpo_artigo: string | null
          created_at: string
          descricao: string | null
          destaque: boolean
          destino: string
          edicao_id: string | null
          email_assunto: string | null
          email_recebido_id: string | null
          email_remetente: string | null
          embedding: unknown
          estado: string
          fonte_estado: string
          fonte_id: string | null
          fonte_url_original: string | null
          id: string
          ordem: number
          origem: string
          override_destino: string
          repeticao_de: string | null
          repeticao_score: number | null
          repeticao_verificada_em: string | null
          titulo: string
          updated_at: string
          url: string | null
          url_curto: string | null
          url_norm: string | null
        }
        Insert: {
          busca?: unknown
          categoria: string
          corpo_artigo?: string | null
          created_at?: string
          descricao?: string | null
          destaque?: boolean
          destino?: string
          edicao_id?: string | null
          email_assunto?: string | null
          email_recebido_id?: string | null
          email_remetente?: string | null
          embedding?: unknown
          estado?: string
          fonte_estado?: string
          fonte_id?: string | null
          fonte_url_original?: string | null
          id?: string
          ordem?: number
          origem: string
          override_destino?: string
          repeticao_de?: string | null
          repeticao_score?: number | null
          repeticao_verificada_em?: string | null
          titulo: string
          updated_at?: string
          url?: string | null
          url_curto?: string | null
          url_norm?: string | null
        }
        Update: {
          busca?: unknown
          categoria?: string
          corpo_artigo?: string | null
          created_at?: string
          descricao?: string | null
          destaque?: boolean
          destino?: string
          edicao_id?: string | null
          email_assunto?: string | null
          email_recebido_id?: string | null
          email_remetente?: string | null
          embedding?: unknown
          estado?: string
          fonte_estado?: string
          fonte_id?: string | null
          fonte_url_original?: string | null
          id?: string
          ordem?: number
          origem?: string
          override_destino?: string
          repeticao_de?: string | null
          repeticao_score?: number | null
          repeticao_verificada_em?: string | null
          titulo?: string
          updated_at?: string
          url?: string | null
          url_curto?: string | null
          url_norm?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "noticias_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "noticias_email_recebido_id_fkey"
            columns: ["email_recebido_id"]
            isOneToOne: false
            referencedRelation: "emails_recebidos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "noticias_fonte_id_fkey"
            columns: ["fonte_id"]
            isOneToOne: false
            referencedRelation: "fontes_curadoria"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "noticias_repeticao_de_fkey"
            columns: ["repeticao_de"]
            isOneToOne: false
            referencedRelation: "noticias"
            referencedColumns: ["id"]
          },
        ]
      }
      perfis: {
        Row: {
          created_at: string
          id: string
          nome: string | null
          papel: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id: string
          nome?: string | null
          papel?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          nome?: string | null
          papel?: string
          updated_at?: string
        }
        Relationships: []
      }
      prioridades_editoriais: {
        Row: {
          created_at: string
          id: string
          palavra_chave: string
          peso: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          palavra_chave: string
          peso?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          palavra_chave?: string
          peso?: number
          updated_at?: string
        }
        Relationships: []
      }
      revista_edicao: {
        Row: {
          bloco_ferramentas: boolean
          created_at: string
          cronica_excerto: string
          cronica_imagem_alt: string
          cronica_imagem_credito: string
          cronica_imagem_credito_url: string
          cronica_imagem_enquadramento: Json
          cronica_imagem_fonte: string
          cronica_imagem_posicao: number
          cronica_imagem_recorte_url: string
          cronica_imagem_url: string
          cronica_lede: string
          cronica_lede_posicao: number
          cronica_subtitulo: string
          cronica_titulo: string
          cronica_url: string
          edicao_id: string
          livro_activo: boolean
          livro_cta: string
          livro_etiqueta: string
          livro_texto: string
          livro_titulo: string
          livro_url: string
          momento_activo: boolean
          momento_descricao: string
          momento_etiqueta: string
          momento_posicao: number
          momento_valor: string
          podcast_activo: boolean
          podcast_convidado: string
          podcast_cta: string
          podcast_etiqueta: string
          podcast_pergunta: string
          podcast_programa: string
          podcast_tema: string
          podcast_url: string
          preheader: string
          promocao_activa: boolean
          promocao_link_texto: string
          promocao_prefixo: string
          promocao_url: string
          pull_quote: string
          pull_quote_posicao: number
          recomendacao_activa: boolean
          recomendacao_meta: string
          recomendacao_nota: string
          recomendacao_tipo: string
          recomendacao_titulo: string
          recomendacao_url: string
          servicos_activo: boolean
          servicos_auditoria_activo: boolean
          servicos_consultoria_activo: boolean
          servicos_consultoria_cta: string
          servicos_consultoria_texto: string
          servicos_consultoria_url: string
          servicos_cta: string
          servicos_cursos_activo: boolean
          servicos_cursos_cta: string
          servicos_cursos_texto: string
          servicos_cursos_url: string
          servicos_intro: string
          servicos_titulo: string
          servicos_url: string
          updated_at: string
        }
        Insert: {
          bloco_ferramentas?: boolean
          created_at?: string
          cronica_excerto?: string
          cronica_imagem_alt?: string
          cronica_imagem_credito?: string
          cronica_imagem_credito_url?: string
          cronica_imagem_enquadramento?: Json
          cronica_imagem_fonte?: string
          cronica_imagem_posicao?: number
          cronica_imagem_recorte_url?: string
          cronica_imagem_url?: string
          cronica_lede?: string
          cronica_lede_posicao?: number
          cronica_subtitulo?: string
          cronica_titulo?: string
          cronica_url?: string
          edicao_id: string
          livro_activo?: boolean
          livro_cta?: string
          livro_etiqueta?: string
          livro_texto?: string
          livro_titulo?: string
          livro_url?: string
          momento_activo?: boolean
          momento_descricao?: string
          momento_etiqueta?: string
          momento_posicao?: number
          momento_valor?: string
          podcast_activo?: boolean
          podcast_convidado?: string
          podcast_cta?: string
          podcast_etiqueta?: string
          podcast_pergunta?: string
          podcast_programa?: string
          podcast_tema?: string
          podcast_url?: string
          preheader?: string
          promocao_activa?: boolean
          promocao_link_texto?: string
          promocao_prefixo?: string
          promocao_url?: string
          pull_quote?: string
          pull_quote_posicao?: number
          recomendacao_activa?: boolean
          recomendacao_meta?: string
          recomendacao_nota?: string
          recomendacao_tipo?: string
          recomendacao_titulo?: string
          recomendacao_url?: string
          servicos_activo?: boolean
          servicos_auditoria_activo?: boolean
          servicos_consultoria_activo?: boolean
          servicos_consultoria_cta?: string
          servicos_consultoria_texto?: string
          servicos_consultoria_url?: string
          servicos_cta?: string
          servicos_cursos_activo?: boolean
          servicos_cursos_cta?: string
          servicos_cursos_texto?: string
          servicos_cursos_url?: string
          servicos_intro?: string
          servicos_titulo?: string
          servicos_url?: string
          updated_at?: string
        }
        Update: {
          bloco_ferramentas?: boolean
          created_at?: string
          cronica_excerto?: string
          cronica_imagem_alt?: string
          cronica_imagem_credito?: string
          cronica_imagem_credito_url?: string
          cronica_imagem_enquadramento?: Json
          cronica_imagem_fonte?: string
          cronica_imagem_posicao?: number
          cronica_imagem_recorte_url?: string
          cronica_imagem_url?: string
          cronica_lede?: string
          cronica_lede_posicao?: number
          cronica_subtitulo?: string
          cronica_titulo?: string
          cronica_url?: string
          edicao_id?: string
          livro_activo?: boolean
          livro_cta?: string
          livro_etiqueta?: string
          livro_texto?: string
          livro_titulo?: string
          livro_url?: string
          momento_activo?: boolean
          momento_descricao?: string
          momento_etiqueta?: string
          momento_posicao?: number
          momento_valor?: string
          podcast_activo?: boolean
          podcast_convidado?: string
          podcast_cta?: string
          podcast_etiqueta?: string
          podcast_pergunta?: string
          podcast_programa?: string
          podcast_tema?: string
          podcast_url?: string
          preheader?: string
          promocao_activa?: boolean
          promocao_link_texto?: string
          promocao_prefixo?: string
          promocao_url?: string
          pull_quote?: string
          pull_quote_posicao?: number
          recomendacao_activa?: boolean
          recomendacao_meta?: string
          recomendacao_nota?: string
          recomendacao_tipo?: string
          recomendacao_titulo?: string
          recomendacao_url?: string
          servicos_activo?: boolean
          servicos_auditoria_activo?: boolean
          servicos_consultoria_activo?: boolean
          servicos_consultoria_cta?: string
          servicos_consultoria_texto?: string
          servicos_consultoria_url?: string
          servicos_cta?: string
          servicos_cursos_activo?: boolean
          servicos_cursos_cta?: string
          servicos_cursos_texto?: string
          servicos_cursos_url?: string
          servicos_intro?: string
          servicos_titulo?: string
          servicos_url?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "revista_edicao_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: true
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
      revista_itens: {
        Row: {
          created_at: string
          cta_rotulo: string
          edicao_id: string
          id: string
          minha_leitura: string
          noticia_id: string
          ordem: number
          papel: string
          radar_nota: string
          resumo_factual: string
          titulo_override: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          cta_rotulo?: string
          edicao_id: string
          id?: string
          minha_leitura?: string
          noticia_id: string
          ordem?: number
          papel: string
          radar_nota?: string
          resumo_factual?: string
          titulo_override?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          cta_rotulo?: string
          edicao_id?: string
          id?: string
          minha_leitura?: string
          noticia_id?: string
          ordem?: number
          papel?: string
          radar_nota?: string
          resumo_factual?: string
          titulo_override?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "revista_itens_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "revista_itens_noticia_id_fkey"
            columns: ["noticia_id"]
            isOneToOne: false
            referencedRelation: "noticias"
            referencedColumns: ["id"]
          },
        ]
      }
      secoes_edicao: {
        Row: {
          activo: boolean
          cor: string | null
          created_at: string
          edicao_id: string
          id: string
          ordem: number
          texto: string | null
          texto_botao: string | null
          tipo: string
          titulo: string | null
          url_botao: string | null
        }
        Insert: {
          activo?: boolean
          cor?: string | null
          created_at?: string
          edicao_id: string
          id?: string
          ordem?: number
          texto?: string | null
          texto_botao?: string | null
          tipo: string
          titulo?: string | null
          url_botao?: string | null
        }
        Update: {
          activo?: boolean
          cor?: string | null
          created_at?: string
          edicao_id?: string
          id?: string
          ordem?: number
          texto?: string | null
          texto_botao?: string | null
          tipo?: string
          titulo?: string | null
          url_botao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "secoes_edicao_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
      subscricao_eventos: {
        Row: {
          accao: string
          criado_em: string
          detalhe: Json
          edicao_id: string | null
          email: string
          id: string
          lista_egoi_id: string | null
          lista_nome: string | null
          motivo: string | null
          origem: string
          retoma_em: string | null
          retomado_em: string | null
        }
        Insert: {
          accao: string
          criado_em?: string
          detalhe?: Json
          edicao_id?: string | null
          email: string
          id?: string
          lista_egoi_id?: string | null
          lista_nome?: string | null
          motivo?: string | null
          origem?: string
          retoma_em?: string | null
          retomado_em?: string | null
        }
        Update: {
          accao?: string
          criado_em?: string
          detalhe?: Json
          edicao_id?: string | null
          email?: string
          id?: string
          lista_egoi_id?: string | null
          lista_nome?: string | null
          motivo?: string | null
          origem?: string
          retoma_em?: string | null
          retomado_em?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscricao_eventos_edicao_id_fkey"
            columns: ["edicao_id"]
            isOneToOne: false
            referencedRelation: "edicoes"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      confirmar_repeticao_por_embedding: {
        Args: {
          _candidato_ids: string[]
          _embedding: unknown
          _limiar?: number
        }
        Returns: {
          distancia: number
          id: string
        }[]
      }
      contar_dados_antigos: { Args: { _dias?: number }; Returns: Json }
      criar_seccoes_padrao: { Args: { _edicao_id: string }; Returns: undefined }
      encontrar_candidatos_repeticao: {
        Args: { _categoria: string; _limiar?: number; _titulo: string }
        Returns: {
          created_at: string
          edicao_id: string
          edicao_numero: number
          id: string
          score: number
          titulo: string
        }[]
      }
      f_unaccent: { Args: { "": string }; Returns: string }
      is_admin: { Args: never; Returns: boolean }
      limpar_dados_antigos: { Args: { _dias?: number }; Returns: Json }
      me_papel: { Args: never; Returns: string }
      mover_seccao: {
        Args: { _direccao: string; _seccao_id: string }
        Returns: undefined
      }
      normalizar_url_sql: { Args: { _url: string }; Returns: string }
      pesquisar_arquivo: {
        Args: { limite?: number; query: string }
        Returns: {
          edicao_data: string
          edicao_id: string
          edicao_numero: number
          rank: number
          tipo: string
          titulo: string
          trecho: string
          url: string
        }[]
      }
      pesquisar_global: {
        Args: {
          ambitos?: string[]
          edicao_actual?: string
          limite?: number
          query: string
        }
        Returns: {
          ambito: string
          categoria: string
          criado_em: string
          edicao_data: string
          edicao_id: string
          edicao_numero: number
          estado: string
          id: string
          origem: string
          rank: number
          tipo: string
          titulo: string
          trecho: string
          url: string
          usada_em_numero: number
        }[]
      }
      registar_evento_brief: {
        Args: { _edicao_numero: number; _evento: string; _slug: string }
        Returns: undefined
      }
      reordenar_noticias: {
        Args: { _edicao_id: string; _ids: string[] }
        Returns: undefined
      }
      reordenar_seccoes: {
        Args: { _edicao_id: string; _ids: string[] }
        Returns: undefined
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
      stats_fontes_30d: {
        Args: never
        Returns: {
          aprovadas_30d: number
          fonte_id: string
          sugeridas_30d: number
        }[]
      }
      unaccent: { Args: { "": string }; Returns: string }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
