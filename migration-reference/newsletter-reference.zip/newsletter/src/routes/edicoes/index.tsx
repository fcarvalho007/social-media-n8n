import { createFileRoute, Link } from "@tanstack/react-router";
import { baseUrlEdicoesFn, listarEdicoesPublicasFn } from "@/lib/revista-web.functions";
import { anoDe, fmtDataCurta } from "@/features/revista-web/ui";

const TITLE = "Arquivo de edições · Digital Sprint";
const DESCRIPTION =
  "Todas as edições publicadas da Digital Sprint: curadoria semanal de marketing, media e tecnologia por Frederico Carvalho.";

export const Route = createFileRoute("/edicoes/")({
  loader: async () => {
    const [edicoes, base] = await Promise.all([listarEdicoesPublicasFn(), baseUrlEdicoesFn()]);
    return { edicoes, base };
  },
  head: ({ loaderData }) => {
    const canonical = `${loaderData?.base ?? ""}/edicoes`;
    return {
      meta: [
        { title: TITLE },
        { name: "description", content: DESCRIPTION },
        { property: "og:title", content: TITLE },
        { property: "og:description", content: DESCRIPTION },
        { property: "og:type", content: "website" },
        { property: "og:url", content: canonical },
        { name: "twitter:card", content: "summary" },
      ],
      links: loaderData?.base ? [{ rel: "canonical", href: canonical }] : [],
    };
  },
  component: ArquivoPublico,
});

function ArquivoPublico() {
  const { edicoes } = Route.useLoaderData();


  // Agrupar por ano: o arquivo lê-se por varrimento, não por leitura linear.
  const anos: Array<{ ano: string; itens: typeof edicoes }> = [];
  for (const ed of edicoes) {
    const ano = anoDe(ed.data) || "—";
    const ultimo = anos[anos.length - 1];
    if (ultimo && ultimo.ano === ano) ultimo.itens.push(ed);
    else anos.push({ ano, itens: [ed] });
  }

  return (
    <div className="rw rw-sala rw-grao min-h-dvh">
      <div className="mx-auto w-full max-w-[48rem] px-5 py-10 sm:px-8 sm:py-16">
        <header className="border-b border-rw-hairline pb-4">
          <p className="font-display text-[13px] font-semibold uppercase tracking-[0.28em] text-rw-chalk">Digital Sprint</p>
        </header>

        <h1 className="rw-entra mt-12 text-balance font-display font-semibold tracking-tight text-rw-chalk text-[34px] leading-[1.1] sm:text-[56px]">
          Arquivo de edições
        </h1>
        <p className="rw-entra mt-5 max-w-[38rem] text-[17px] leading-[1.7] text-rw-chalk-2">
          Curadoria semanal de marketing, media e tecnologia. Cada edição reúne a crónica, as três coisas que não
          ignorarias, o radar e todas as atualidades da semana.
        </p>

        {edicoes.length === 0 ? (
          <p className="mt-12 border-t border-rw-hairline pt-6 text-[16px] text-rw-chalk-2">
            Ainda não há edições publicadas.
          </p>
        ) : (
          anos.map((grupo) => (
            <section key={grupo.ano} className="mt-12" aria-labelledby={`ano-${grupo.ano}`}>
              <h2
                id={`ano-${grupo.ano}`}
                className="border-b border-rw-hairline pb-1 text-[12.5px] font-semibold uppercase tracking-[0.18em] text-rw-ciano"
              >
                {grupo.ano}
              </h2>
              <ul>
                {grupo.itens.map((ed) => (
                  <li key={ed.numero} className="border-b border-rw-hairline">
                    <Link
                      to="/edicoes/$numero"
                      params={{ numero: String(ed.numero) }}
                      className="group grid grid-cols-[minmax(0,1fr)] gap-1 py-5 sm:grid-cols-[7rem_minmax(0,1fr)] sm:gap-6"
                    >
                      <span className="text-[11.5px] font-semibold uppercase tracking-[0.18em] text-rw-chalk-2 sm:pt-1.5">
                        #{ed.numero}
                        {ed.data ? ` · ${fmtDataCurta(ed.data)}` : ""}
                      </span>
                      <span className="min-w-0">
                        <span className="block text-[19px] font-semibold leading-7 tracking-tight text-rw-chalk underline-offset-4 group-hover:text-rw-ciano sm:text-[22px] sm:leading-8">
                          {ed.titulo}
                        </span>
                        {ed.lede ? (
                          <span className="mt-1 block text-[15.5px] leading-7 text-rw-chalk-2">{ed.lede}</span>
                        ) : null}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ))
        )}
      </div>
    </div>
  );
}
